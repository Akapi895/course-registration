# Kết quả kiểm thử Phase 1

PASS/FAIL dựa trên ngưỡng bài thử, chưa phải SLA hiệu năng trong SRS.
INCONCLUSIVE: bằng chứng chưa đủ để kết luận năng lực hoặc tính đúng đắn.
FINDING: quan sát cần gia cố, không đồng nghĩa đã gây từ chối dịch vụ thành công.

## Môi trường
- cores: 4
- cpu_model: Intel(R) Xeon(R) CPU @ 2.20GHz
- server_cpus: 0,1
- attacker_cpus: 2,3
- cpu_isolated: True
- postgres_version: 16.15 (Ubuntu 16.15-1.pgdg24.04+2)
- python: 3.13.15
- load_students: 4000
- api_config: {'JWT_TTL': '4h', 'SESSION_TTL': '4h', 'ADMIN_JWT_TTL': '8h', 'LOGIN_COOLDOWN': '20m', 'MAX_CREDITS': '26'}
- commit: 669e485752f3d524036089daab43f5ed1a493ff6
- api_sha256: e4a93c76d62e7895e1408fc2dff5de7af350d9a14b41062dfc79631b88f24d29

## Trạng thái thực thi
- perf: COMPLETED
- race: COMPLETED
- abuse: ERROR — RuntimeError: API exited with 1:
127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:03 | 200 |   5.79ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:03 | 200 |   5.33ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 | 68.681µs |       127.0.0.1 | GET      "/health"
[GIN] 2026/10/29 - 20:54:04 | 200 | 54.733µs |       127.0.0.1 | GET      "/health"
[GIN] 2026/10/29 - 20:54:04 | 200 |  11.51ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |    6.5ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   6.48ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   7.26ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   5.69ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   5.84ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   5.02ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   5.15ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   5.66ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   6.53ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   5.71ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   5.71ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   5.67ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   5.89ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   7.16ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   5.04ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   5.36ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   5.16ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |      5ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:04 | 200 |   5.17ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:05 | 401 | 556.14ms |       127.0.0.1 | POST     "/api/auth/login"
[GIN] 2026/10/29 - 20:54:08 | 401 |     2.8s |       127.0.0.1 | POST     "/api/auth/login"
[GIN] 2026/10/29 - 20:54:08 | 200 | 27.492µs |       127.0.0.1 | GET      "/health"
[GIN] 2026/10/29 - 20:54:08 | 200 |   5.87ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:08 | 200 |   5.69ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:08 | 200 |   6.08ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:08 | 200 |   5.26ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:08 | 200 |    5.4ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:09 | 200 | 14.724µs |       127.0.0.1 | GET      "/health"
[GIN] 2026/10/29 - 20:54:09 | 200 |   5.88ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:09 | 200 |    6.2ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:09 | 200 |   6.33ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:09 | 200 |   6.35ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:09 | 200 |   6.37ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:10 | 200 | 18.124µs |       127.0.0.1 | GET      "/health"
[GIN] 2026/10/29 - 20:54:10 | 200 |   5.88ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:10 | 200 |   7.49ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:10 | 200 |   5.98ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:10 | 200 |   5.61ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:54:10 | 200 |   5.43ms |       127.0.0.1 | GET      "/api/classes"
2026/10/29 20:54:10 listen tcp :8080: bind: address already in use

- window: ERROR — ConnectError: [Errno 111] Connection refused

## Hiệu năng
Ngưỡng: HTTP p95 ≤ 500.0 ms; lỗi HTTP/kết nối/giao thức và thao tác ≤ 1.0%.
Percentile được tính từ histogram gộp các worker (làm tròn lên 1 ms).
Tốc độ đến của bài đăng ký tính theo thao tác; mỗi thao tác có thể tạo nhiều request HTTP.

| case | status | accounts used | req/s | p95 ms | p99 ms | HTTP error % | operation error % | dropped |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| a1-baseline | PASS | 1 | 213.5 | 8 | 10 | 0.0 | 0.0 | 0 |
| a2-read-1000 | FAIL | 1000 | 473.28 | 1794 | 1930 | 0.0 | 0.0 | 0 |
| a2-read-200 | PASS | 200 | 198.08 | 20 | 30 | 0.0 | 0.0 | 0 |
| a2-read-2000 | FAIL | 2000 | 450.63 | 5171 | 5414 | 0.0 | 0.0 | 0 |
| a2-read-3000 | FAIL | 3000 | 424.15 | 8619 | 9438 | 0.0 | 0.0 | 0 |
| a2-read-4000 | FAIL | 4000 | 463.33 | 10006 | 10038 | 8.223 | 8.223 | 0 |
| a2-read-500 | PASS | 500 | 458.28 | 194 | 251 | 0.0 | 0.0 | 0 |
| a3-small-1000 | PASS | 1000 | 863.73 | 241 | 327 | 0.0 | 0.0 | 0 |
| a3-small-200 | PASS | 200 | 249.45 | 28 | 34 | 0.0 | 0.0 | 0 |
| a3-small-2000 | FAIL | 2000 | 918.85 | 1272 | 1353 | 0.0 | 0.0 | 0 |
| a3-small-3000 | FAIL | 3000 | 882.83 | 2559 | 2615 | 0.0 | 0.0 | 0 |
| a3-small-4000 | FAIL | 4000 | 825.57 | 4069 | 4118 | 0.0 | 0.0 | 0 |
| a3-small-500 | PASS | 500 | 559.93 | 42 | 51 | 0.0 | 0.0 | 0 |
| a3-wide-1000 | FAIL | 1000 | 307.15 | 8421 | 8816 | 0.0 | 32.084 | 0 |
| a3-wide-200 | FAIL | 200 | 306.75 | 1595 | 1729 | 0.0 | 0.0 | 0 |
| a3-wide-2000 | FAIL | 2000 | 303.85 | 8998 | 10002 | 1.629 | 100.0 | 0 |
| a3-wide-3000 | FAIL | 3000 | 299.07 | 10845 | 10899 | 64.885 | 100.0 | 0 |
| a3-wide-4000 | FAIL | 4000 | 343.95 | 10861 | 10919 | 94.127 | 100.0 | 0 |
| a3-wide-500 | FAIL | 500 | 307.87 | 4294 | 4620 | 0.0 | 0.0 | 0 |
| a4-read-rate-100 | PASS | 4000 | 100.0 | 12 | 19 | 0.0 | 0.0 | 0 |
| a4-read-rate-200 | PASS | 4000 | 200.0 | 23 | 70 | 0.0 | 0.0 | 0 |
| a4-read-rate-400 | PASS | 4000 | 400.0 | 68 | 95 | 0.0 | 0.0 | 0 |
| a4-read-rate-800 | INCONCLUSIVE | 4000 | 424.17 | 10001 | 10004 | 5.328 | 5.328 | 22551 |
| a4-registration-rate-100 | INCONCLUSIVE | 4000 | 196.5 | 10003 | 10005 | 28.88 | 97.698 | 6 |
| a4-registration-rate-25 | PASS | 1500 | 150.0 | 36 | 40 | 0.0 | 0.0 | 0 |
| a4-registration-rate-37-repeat-2 | PASS | 2220 | 221.85 | 40 | 52 | 0.0 | 0.0 | 0 |
| a4-registration-rate-37-repeat-3 | PASS | 2220 | 221.93 | 45 | 54 | 0.0 | 0.0 | 0 |
| a4-registration-rate-50 | FAIL | 3000 | 293.35 | 733 | 1064 | 0.0 | 0.0 | 0 |
| a4-registration-rate-50-repeat-2 | FAIL | 3000 | 230.62 | 9394 | 10003 | 3.086 | 14.233 | 0 |
| a4-registration-rate-50-repeat-3 | FAIL | 3000 | 292.33 | 1152 | 1774 | 0.0 | 0.0 | 0 |
| a4-registration-refine-37 | PASS | 2220 | 221.98 | 39 | 44 | 0.0 | 0.0 | 0 |
| a5-read-spike | FAIL | 4000 | 352.17 | 10002 | 10017 | 5.876 | 5.876 | 0 |
| a5-recovery | PASS | 10 | 48.53 | 10 | 13 | 0.0 | 0.0 | 0 |
| a5-registration-burst-4000-30s | INCONCLUSIVE | 3996 | 242.32 | 10003 | 10005 | 41.68 | 78.353 | 4 |
| a5-registration-burst-4000-5s | FAIL | 4000 | 668.67 | 10010 | 10031 | 98.704 | 99.0 | 0 |
| a6-soak | FAIL | 500 | 360.69 | 3075 | 3233 | 0.0 | 0.0 | 0 |
| a7-admin-login-16 | FAIL | 16 | 5.88 | 3130 | 3237 | 0.0 | 0.0 | 0 |
| a7-admin-login-4 | FAIL | 4 | 5.95 | 755 | 780 | 0.0 | 0.0 | 0 |
| a7-admin-login-64 | FAIL | 64 | 6.4 | 10020 | 10023 | 99.74 | 99.74 | 0 |
| a7-student-login-burst-4000 | FAIL | 4000 | 133.33 | 10003 | 10017 | 100.0 | 100.0 | 0 |

### Khoảng giới hạn đo được
- read: tốc độ đến lớn nhất quan sát còn đạt = 400 thao tác/s; mức không đạt phía trên = None thao tác/s.
  - Tại mức đó: throughput HTTP trung vị 400.00 req/s (khoảng 400.00–400.00); 1 lần đo.
  - Chưa xác nhận giới hạn: thiếu lần lặp, bậc không đạt phía trên hoặc năng lực bộ phát tải.
- registration: tốc độ đến lớn nhất quan sát còn đạt = 37 thao tác/s; mức không đạt phía trên = 50 thao tác/s.
  - Tại mức đó: throughput HTTP trung vị 221.93 req/s (khoảng 221.85–221.98); 3 lần đo.
  - Khoảng đạt/không đạt đã được lặp ít nhất ba lần ở cả hai phía.

### Chi tiết theo case
- a1-baseline: PASS
  - business: {}; errors: {}
  - operation p95/p99: 10/12 ms; counters: {'issued': 12810, 'flow_completed': 12810, 'unfinished': 0}
  - resources: {'cpu': {'api': 34.55, 'postgres': 46.24, 'generator': 35.2}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 51.15, 'db_max_lock_waiters': 0, 'db_max_connections': 2, 'samples': 60, 'error': None}
- a2-read-1000: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 1798/1933 ms; counters: {'issued': 28397, 'flow_completed': 28397, 'unfinished': 0}
  - resources: {'cpu': {'api': 78.61, 'postgres': 116.36, 'generator': 112.88}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 111.25, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a2-read-200: PASS
  - business: {}; errors: {}
  - operation p95/p99: 23/34 ms; counters: {'issued': 11885, 'flow_completed': 11885, 'unfinished': 0}
  - resources: {'cpu': {'api': 32.45, 'postgres': 44.35, 'generator': 43.82}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 61.01, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a2-read-2000: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 5174/5417 ms; counters: {'issued': 27038, 'flow_completed': 27038, 'unfinished': 0}
  - resources: {'cpu': {'api': 79.46, 'postgres': 116.02, 'generator': 111.33}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 180.69, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a2-read-3000: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 8622/9442 ms; counters: {'issued': 25449, 'flow_completed': 25449, 'unfinished': 0}
  - resources: {'cpu': {'api': 82.84, 'postgres': 110.61, 'generator': 114.43}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 247.31, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a2-read-4000: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/classes: 0, original=timed out': 2286}
  - operation p95/p99: 10006/10038 ms; counters: {'issued': 27800, 'flow_completed': 25514, 'flow_failed': 2286, 'unfinished': 0}
  - resources: {'cpu': {'api': 80.57, 'postgres': 87.13, 'generator': 108.13}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 302.32, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 58, 'error': None}
- a2-read-500: PASS
  - business: {}; errors: {}
  - operation p95/p99: 197/255 ms; counters: {'issued': 27497, 'flow_completed': 27497, 'unfinished': 0}
  - resources: {'cpu': {'api': 73.9, 'postgres': 118.4, 'generator': 111.08}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 74.5, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-small-1000: PASS
  - business: {'CLASS_FULL': 50074, 'registered': 876}; errors: {}
  - operation p95/p99: 255/380 ms; counters: {'issued': 50950, 'flow_completed': 50950, 'unfinished': 0}
  - resources: {'cpu': {'api': 80.38, 'postgres': 99.46, 'generator': 72.26}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 116.18, 'db_max_lock_waiters': 3, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-small-200: PASS
  - business: {'registered': 3291, 'CLASS_FULL': 8385}; errors: {}
  - operation p95/p99: 42/53 ms; counters: {'issued': 11676, 'flow_completed': 11676, 'unfinished': 0}
  - resources: {'cpu': {'api': 31.89, 'postgres': 40.01, 'generator': 23.09}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 212.04, 'db_max_lock_waiters': 3, 'db_max_connections': 5, 'samples': 59, 'error': None}
- a3-small-2000: latency or HTTP/transport error threshold exceeded
  - business: {'CLASS_FULL': 54876, 'registered': 126}; errors: {}
  - operation p95/p99: 1272/1354 ms; counters: {'issued': 55002, 'flow_completed': 55002, 'unfinished': 0}
  - resources: {'cpu': {'api': 82.97, 'postgres': 103.84, 'generator': 77.18}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 168.46, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-small-3000: latency or HTTP/transport error threshold exceeded
  - business: {'CLASS_FULL': 52844, 'registered': 63}; errors: {}
  - operation p95/p99: 2559/2616 ms; counters: {'issued': 52907, 'flow_completed': 52907, 'unfinished': 0}
  - resources: {'cpu': {'api': 84.66, 'postgres': 101.42, 'generator': 87.02}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 230.19, 'db_max_lock_waiters': 2, 'db_max_connections': 4, 'samples': 58, 'error': None}
- a3-small-4000: latency or HTTP/transport error threshold exceeded
  - business: {'CLASS_FULL': 49456, 'registered': 39}; errors: {}
  - operation p95/p99: 4069/4118 ms; counters: {'issued': 49495, 'flow_completed': 49495, 'unfinished': 0}
  - resources: {'cpu': {'api': 85.29, 'postgres': 99.36, 'generator': 91.9}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 279.06, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 58, 'error': None}
- a3-small-500: PASS
  - business: {'registered': 4513, 'CLASS_FULL': 24572}; errors: {}
  - operation p95/p99: 60/78 ms; counters: {'issued': 29085, 'flow_completed': 29085, 'unfinished': 0}
  - resources: {'cpu': {'api': 63.14, 'postgres': 78.46, 'generator': 48.83}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 92.89, 'db_max_lock_waiters': 3, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-wide-1000: latency or HTTP/transport error threshold exceeded
  - business: {'ALREADY_REGISTERED': 5768, 'registered': 16642}; errors: {}
  - operation p95/p99: 17546/17586 ms; counters: {'issued': 4482, 'flow_failed': 1438, 'flow_completed': 3044, 'unfinished': 0}
  - resources: {'cpu': {'api': 63.05, 'postgres': 90.61, 'generator': 27.71}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 122.95, 'db_max_lock_waiters': 1, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-wide-200: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 15020}; errors: {}
  - operation p95/p99: 3500/3555 ms; counters: {'issued': 3004, 'flow_completed': 3004, 'unfinished': 0}
  - resources: {'cpu': {'api': 62.5, 'postgres': 91.24, 'generator': 27.17}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 82.52, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-wide-2000: latency or HTTP/transport error threshold exceeded
  - business: {'ALREADY_REGISTERED': 37676, 'registered': 9689}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 297}
  - operation p95/p99: 12189/14030 ms; counters: {'issued': 9770, 'flow_failed': 9770, 'unfinished': 0}
  - resources: {'cpu': {'api': 67.76, 'postgres': 95.95, 'generator': 29.38}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 180.09, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-wide-3000: latency or HTTP/transport error threshold exceeded
  - business: {'ALREADY_REGISTERED': 12754, 'registered': 3581}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 11643}
  - operation p95/p99: 13673/15266 ms; counters: {'issued': 14910, 'flow_failed': 14910, 'unfinished': 0}
  - resources: {'cpu': {'api': 70.32, 'postgres': 91.56, 'generator': 32.84}, 'generator_busy_fraction': 0.03389830508474576, 'api_peak_rss_mb': 230.57, 'db_max_lock_waiters': 0, 'db_max_connections': 5, 'samples': 59, 'error': None}
- a3-wide-4000: latency or HTTP/transport error threshold exceeded
  - business: {'ALREADY_REGISTERED': 1808, 'registered': 977}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 19425}
  - operation p95/p99: 10878/15379 ms; counters: {'issued': 19982, 'flow_failed': 19982, 'unfinished': 0}
  - resources: {'cpu': {'api': 71.95, 'postgres': 91.24, 'generator': 40.94}, 'generator_busy_fraction': 0.0847457627118644, 'api_peak_rss_mb': 297.88, 'db_max_lock_waiters': 1, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-wide-500: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 15055}; errors: {}
  - operation p95/p99: 9424/9480 ms; counters: {'issued': 3011, 'flow_completed': 3011, 'unfinished': 0}
  - resources: {'cpu': {'api': 62.33, 'postgres': 90.16, 'generator': 27.57}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 96.41, 'db_max_lock_waiters': 1, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-read-rate-100: PASS
  - business: {}; errors: {}
  - operation p95/p99: 16/23 ms; counters: {'scheduled': 6000, 'issued': 6000, 'flow_completed': 6000, 'unfinished': 0}
  - resources: {'cpu': {'api': 26.05, 'postgres': 24.41, 'generator': 31.35}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 183.27, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-read-rate-200: PASS
  - business: {}; errors: {}
  - operation p95/p99: 27/71 ms; counters: {'scheduled': 12000, 'issued': 12000, 'flow_completed': 12000, 'unfinished': 0}
  - resources: {'cpu': {'api': 47.73, 'postgres': 53.04, 'generator': 60.69}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 187.83, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-read-rate-400: PASS
  - business: {}; errors: {}
  - operation p95/p99: 71/98 ms; counters: {'scheduled': 24000, 'issued': 24000, 'flow_completed': 24000, 'unfinished': 0}
  - resources: {'cpu': {'api': 75.77, 'postgres': 103.57, 'generator': 111.17}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 202.63, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 58, 'error': None}
- a4-read-rate-800: generator dropped, failed or did not finish operations
  - business: {}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/classes: 0, original=timed out': 1356}
  - operation p95/p99: 10002/10004 ms; counters: {'scheduled': 48000, 'dropped': 22551, 'scheduler_late': 128, 'issued': 25450, 'flow_completed': 24094, 'flow_failed': 1356, 'unfinished': 0}
  - resources: {'cpu': {'api': 80.11, 'postgres': 96.57, 'generator': 116.69}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 288.28, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 58, 'error': None}
- a4-registration-rate-100: generator dropped, failed or did not finish operations
  - business: {'registered': 4912, 'ALREADY_REGISTERED': 8033}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 3405}
  - operation p95/p99: 12788/21079 ms; counters: {'scheduled': 6000, 'issued': 5994, 'flow_failed': 5856, 'dropped': 6, 'scheduler_late': 6, 'flow_completed': 138, 'unfinished': 0}
  - resources: {'cpu': {'api': 62.75, 'postgres': 61.78, 'generator': 29.19}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 171.88, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-registration-rate-25: PASS
  - business: {'registered': 7500}; errors: {}
  - operation p95/p99: 76/84 ms; counters: {'scheduled': 1500, 'issued': 1500, 'flow_completed': 1500, 'unfinished': 0}
  - resources: {'cpu': {'api': 40.27, 'postgres': 47.73, 'generator': 16.73}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 133.25, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-registration-rate-37-repeat-2: PASS
  - business: {'registered': 11100}; errors: {}
  - operation p95/p99: 105/229 ms; counters: {'scheduled': 2220, 'issued': 2220, 'flow_completed': 2220, 'unfinished': 0}
  - resources: {'cpu': {'api': 52.75, 'postgres': 68.58, 'generator': 27.77}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 134.91, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-registration-rate-37-repeat-3: PASS
  - business: {'registered': 11100}; errors: {}
  - operation p95/p99: 107/129 ms; counters: {'scheduled': 2220, 'issued': 2220, 'flow_completed': 2220, 'unfinished': 0}
  - resources: {'cpu': {'api': 53.7, 'postgres': 70.3, 'generator': 28.22}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 134.7, 'db_max_lock_waiters': 0, 'db_max_connections': 5, 'samples': 59, 'error': None}
- a4-registration-rate-50: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 15000}; errors: {}
  - operation p95/p99: 2576/2634 ms; counters: {'scheduled': 3000, 'issued': 3000, 'flow_completed': 3000, 'unfinished': 0}
  - resources: {'cpu': {'api': 64.41, 'postgres': 89.36, 'generator': 38.88}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 162.29, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-registration-rate-50-repeat-2: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 12865}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 427}
  - operation p95/p99: 23328/23448 ms; counters: {'scheduled': 3000, 'issued': 3000, 'flow_completed': 2573, 'flow_failed': 427, 'unfinished': 0}
  - resources: {'cpu': {'api': 61.22, 'postgres': 82.88, 'generator': 31.9}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 168.47, 'db_max_lock_waiters': 1, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-registration-rate-50-repeat-3: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 15000}; errors: {}
  - operation p95/p99: 4293/4320 ms; counters: {'scheduled': 3000, 'issued': 3000, 'flow_completed': 3000, 'unfinished': 0}
  - resources: {'cpu': {'api': 65.27, 'postgres': 89.7, 'generator': 38.71}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 161.0, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-registration-refine-37: PASS
  - business: {'registered': 11100}; errors: {}
  - operation p95/p99: 85/101 ms; counters: {'scheduled': 2220, 'issued': 2220, 'flow_completed': 2220, 'unfinished': 0}
  - resources: {'cpu': {'api': 52.44, 'postgres': 67.81, 'generator': 27.47}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 136.23, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a5-read-spike: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/classes: 0, original=timed out': 1966}
  - operation p95/p99: 10003/10019 ms; counters: {'issued': 33456, 'flow_completed': 31490, 'flow_failed': 1966, 'unfinished': 0}
  - resources: {'cpu': {'api': 62.42, 'postgres': 66.27, 'generator': 85.5}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 296.04, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 93, 'error': None}
- a5-recovery: PASS
  - business: {}; errors: {}
  - operation p95/p99: 12/15 ms; counters: {'issued': 2912, 'flow_completed': 2912, 'unfinished': 0}
  - resources: {'cpu': {'api': 9.29, 'postgres': 10.48, 'generator': 9.97}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 72.24, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a5-registration-burst-4000-30s: not all requested accounts issued a measured operation; generator dropped, failed or did not finish operations
  - business: {'registered': 4325}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 3131}
  - operation p95/p99: 29768/32432 ms; counters: {'scheduled': 4000, 'issued': 3996, 'flow_completed': 865, 'flow_failed': 3131, 'dropped': 4, 'scheduler_late': 4, 'unfinished': 0}
  - resources: {'cpu': {'api': 62.55, 'postgres': 74.93, 'generator': 36.28}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 217.14, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 31, 'error': None}
- a5-registration-burst-4000-5s: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 200}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 3960}
  - operation p95/p99: 10016/10113 ms; counters: {'scheduled': 4000, 'issued': 4000, 'flow_failed': 3960, 'flow_completed': 40, 'unfinished': 0}
  - resources: {'cpu': {'api': 68.15, 'postgres': 89.28, 'generator': 84.63}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 213.3, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 6, 'error': None}
- a6-soak: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 108380}; errors: {}
  - operation p95/p99: 7577/7853 ms; counters: {'issued': 108009, 'flow_completed': 108009, 'unfinished': 0}
  - resources: {'cpu': {'api': 67.37, 'postgres': 98.05, 'generator': 54.42}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 93.98, 'db_max_lock_waiters': 1, 'db_max_connections': 5, 'samples': 594, 'error': None}
- a7-admin-login-16: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 3130/3237 ms; counters: {'issued': 353, 'flow_completed': 353, 'unfinished': 0}
  - resources: {'cpu': {'api': 198.83, 'postgres': 0.9, 'generator': 0.57}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 43.16, 'db_max_lock_waiters': 3, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a7-admin-login-4: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 755/780 ms; counters: {'issued': 357, 'flow_completed': 357, 'unfinished': 0}
  - resources: {'cpu': {'api': 199.04, 'postgres': 0.75, 'generator': 0.57}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 92.32, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a7-admin-login-64: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/auth/login: 0, original=timed out': 383}
  - operation p95/p99: 10020/10023 ms; counters: {'issued': 384, 'flow_failed': 383, 'unfinished': 0, 'flow_completed': 1}
  - resources: {'cpu': {'api': 199.33, 'postgres': 0.22, 'generator': 0.47}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 49.32, 'db_max_lock_waiters': 2, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a7-student-login-burst-4000: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/auth/login: 0, original=timed out': 4000}
  - operation p95/p99: 10004/10017 ms; counters: {'scheduled': 4000, 'issued': 4000, 'flow_failed': 4000, 'unfinished': 0}
  - resources: {'cpu': {'api': 189.76, 'postgres': 0.6, 'generator': 38.1}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 132.78, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 15, 'error': None}

## Đồng thời
- b1: FAIL — B1 class capacity race; requested rounds=20
  - {"name": "B1 class capacity race", "levels": [{"parallelism": 8, "rounds": 20, "violations": 0, "errors": []}, {"parallelism": 32, "rounds": 20, "violations": 0, "errors": []}, {"parallelism": 80, "rounds": 20, "violations": 20, "errors": ["round 0: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 1: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 2: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 3: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 4: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 5: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 6: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 7: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 8: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 9: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 10: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 11: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 12: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 13: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 14: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 15: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 16: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 17: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 18: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 19: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it"]}], "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:35:49.033842+00:00", "table_counts": {"users": 8102, "course_classes": 579, "registrations": 4103, "auth_sessions": 4993}, "violation_counts": {}, "violations": {}}, "status": "FAIL", "rounds_requested": 20}
- b2: PASS — B2 duplicate registration race (same account); requested rounds=20
  - {"name": "B2 duplicate registration race (same account)", "levels": [{"parallelism": 8, "rounds": 20, "violations": 0, "errors": []}, {"parallelism": 32, "rounds": 20, "violations": 0, "errors": []}, {"parallelism": 128, "rounds": 20, "violations": 0, "errors": []}], "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:36:04.244844+00:00", "table_counts": {"users": 8102, "course_classes": 579, "registrations": 4103, "auth_sessions": 4993}, "violation_counts": {}, "violations": {}}, "status": "PASS", "rounds_requested": 20}
- b3: PASS — B3 credit limit race; requested rounds=20
  - {"name": "B3 credit limit race", "rounds": 20, "violations": 0, "errors": [], "note": "10 sections x 3 credits, limit 26", "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:36:07.571231+00:00", "table_counts": {"users": 8102, "course_classes": 579, "registrations": 4103, "auth_sessions": 4993}, "violation_counts": {}, "violations": {}}, "status": "PASS", "rounds_requested": 20}
- b4: PASS — B4 schedule conflict race (same account); requested rounds=20
  - {"name": "B4 schedule conflict race (same account)", "levels": [{"parallelism": 8, "rounds": 20, "violations": 0, "errors": []}, {"parallelism": 32, "rounds": 20, "violations": 0, "errors": []}, {"parallelism": 128, "rounds": 20, "violations": 0, "errors": []}], "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:36:22.074090+00:00", "table_counts": {"users": 8102, "course_classes": 579, "registrations": 4103, "auth_sessions": 4993}, "violation_counts": {}, "violations": {}}, "status": "PASS", "rounds_requested": 20}
- b5: PASS — B5 double-cancel race; requested rounds=20
  - {"name": "B5 double-cancel race", "rounds": 20, "violations": 0, "errors": [], "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:36:23.710645+00:00", "table_counts": {"users": 8102, "course_classes": 579, "registrations": 4103, "auth_sessions": 4993}, "violation_counts": {}, "violations": {}}, "status": "PASS", "rounds_requested": 20}
- b6: PASS — B6 admin cancel vs registration storm; requested rounds=20
  - {"name": "B6 admin cancel vs registration storm", "rounds": 10, "parallelism": 20, "violations": 0, "errors": [], "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:36:25.369785+00:00", "table_counts": {"users": 8102, "course_classes": 589, "registrations": 4103, "auth_sessions": 4993}, "violation_counts": {}, "violations": {}}, "status": "PASS", "rounds_requested": 20}
- b7: PASS — B7 admin update vs registration; requested rounds=20
  - {"name": "B7 admin update vs registration", "rounds": 10, "violations": 0, "errors": [], "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:36:26.986368+00:00", "table_counts": {"users": 8102, "course_classes": 599, "registrations": 4103, "auth_sessions": 4993}, "violation_counts": {}, "violations": {}}, "status": "PASS", "rounds_requested": 20}
- b8: FAIL — B8 concurrent first-time login; requested rounds=20
  - {"name": "B8 concurrent first-time login", "levels": [{"parallelism": 8, "student_rounds": 20, "student_violations": 0, "student_skipped": 0, "student_errors": [], "admin_rounds": 20, "admin_violations": 0, "admin_errors": []}, {"parallelism": 32, "student_rounds": 20, "student_violations": 0, "student_skipped": 0, "student_errors": [], "admin_rounds": 20, "admin_violations": 0, "admin_errors": []}, {"parallelism": 128, "student_rounds": 20, "student_violations": 20, "student_skipped": 0, "student_errors": ["round 0 (racelogind2b6b9837182): ok=1 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 1 (racelogin8ea494a924e9): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 2 (racelogindc5b5baac2ab): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 3 (racelogin4408b6d038de): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 4 (raceloginf16e54c163d7): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 5 (racelogin611dc28da181): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 6 (racelogin2156a8ae1fb9): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 7 (racelogin2ca700e24264): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 8 (racelogin50b590d1a9ad): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 9 (racelogin604bbb298a87): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 10 (racelogin2f802e0012e7): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 11 (racelogine1ece59f3050): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 12 (racelogind70b6946a93d): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 13 (racelogin02de74047597): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 14 (raceloginb598fcfc64c6): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 15 (racelogin36324dd4b8b1): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 16 (raceloginc612d1b8ca14): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 17 (raceloginb953020be1b9): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 18 (racelogin010ee2ca91ae): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 19 (racelogin2f8bfa34f836): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']"], "admin_rounds": 20, "admin_violations": 20, "admin_errors": ["round 0: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 1: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 2: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 3: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 4: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 5: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 6: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 7: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 8: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 9: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 10: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 11: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 12: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 13: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 14: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 15: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 16: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 17: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 18: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 19: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']"]}], "note": "fresh student account for every round; HTTP outcomes and active sessions saved separately", "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:51:21.578537+00:00", "table_counts": {"users": 8162, "course_classes": 599, "registrations": 4103, "auth_sessions": 5834}, "violation_counts": {}, "violations": {}}, "status": "FAIL", "rounds_requested": 20}
- b9: INCONCLUSIVE — b9; requested rounds=20
  - {"name": "b9", "status": "INCONCLUSIVE", "error": "ReadTimeout: timed out", "rounds_requested": 20}
- b11: PASS — B11 natural token expiry; requested rounds=20
  - {"name": "B11 natural token expiry", "rounds": 1, "expires_at": 1793307102, "before": {"http": 200, "code": null, "elapsed_ms": 2.96}, "after": [{"http": 401, "code": "UNAUTHORIZED", "elapsed_ms": 1.54, "body": "{\"status\":\"fail\",\"data\":{\"code\":\"UNAUTHORIZED\",\"message\":\"Chưa đăng nhập hoặc phiên không hợp lệ\"}}"}, {"http": 401, "code": "UNAUTHORIZED", "elapsed_ms": 0.9, "body": "{\"status\":\"fail\",\"data\":{\"code\":\"UNAUTHORIZED\",\"message\":\"Chưa đăng nhập hoặc phiên không hợp lệ\"}}"}, {"http": 401, "code": "UNAUTHORIZED", "elapsed_ms": 0.85, "body": "{\"status\":\"fail\",\"data\":{\"code\":\"UNAUTHORIZED\",\"message\":\"Chưa đăng nhập hoặc phiên không hợp lệ\"}}"}], "violations": 0, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:51:43.169962+00:00", "table_counts": {"users": 8164, "course_classes": 599, "registrations": 4103, "auth_sessions": 5835}, "violation_counts": {}, "violations": {}}, "status": "PASS", "rounds_requested": 20}

## Chống chịu
- c1: {"failed_logins_per_s": 6.7, "reader_baseline_p95_s": 0.012593939999533177, "reader_under_flood_p95_s": 0.9189450769999894, "reader_requests": 26, "login_statuses": {"401": 100}, "reader_errors": {}, "status": "FAIL", "baseline": {"p50_s": 0.007730584999990242, "p95_s": 0.015392639999845414}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.12, "read_p95_s": 0.007357497000157309, "threshold_s": 0.04617791999953624, "api_footprint": {"rss_mb": 50.9, "fds": 32, "threads": 5}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:52:04.236722+00:00", "table_counts": {"users": 8164, "course_classes": 599, "registrations": 4103, "auth_sessions": 5835}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c2: {"requests_per_s": 787.8, "/health 200": 3939, "/api/classes 401": 3939, "/api/missing 404": 3939, "status": "PASS", "baseline": {"p50_s": 0.007651350999367423, "p95_s": 0.014854376000585034}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.12, "read_p95_s": 0.009438823999516899, "threshold_s": 0.0445631280017551, "api_footprint": {"rss_mb": 48.2, "fds": 11, "threads": 5}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:52:23.271909+00:00", "table_counts": {"users": 8164, "course_classes": 599, "registrations": 4103, "auth_sessions": 5835}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c3: {"requested": 1000, "opened": 1000, "open_after_hold": 1000, "hold_s": 60, "fresh_request_status": 200, "fresh_request_s": 0.037, "api_before": {"rss_mb": 46.4, "fds": 9, "threads": 6}, "api_while_held": {"rss_mb": 52.1, "fds": 1009, "threads": 6}, "status": "FINDING", "baseline": {"p50_s": 0.007641398000487243, "p95_s": 0.013144826999450743}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.13, "read_p95_s": 0.007759597000585927, "threshold_s": 0.03943448099835223, "api_footprint": {"rss_mb": 58.8, "fds": 9, "threads": 6}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:53:28.317501+00:00", "table_counts": {"users": 8164, "course_classes": 599, "registrations": 4103, "auth_sessions": 5835}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c4: {"requested": 100, "opened": 100, "open_after_hold": 100, "hold_s": 30, "fresh_request_status": 200, "fresh_request_s": 0.047, "api_before": {"rss_mb": 48.3, "fds": 9, "threads": 6}, "api_while_held": {"rss_mb": 48.5, "fds": 109, "threads": 6}, "status": "FINDING", "baseline": {"p50_s": 0.0075257329999658396, "p95_s": 0.014090112999838311}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.12, "read_p95_s": 0.007400955000775866, "threshold_s": 0.042270338999514934, "api_footprint": {"rss_mb": 48.9, "fds": 9, "threads": 6}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:54:03.234241+00:00", "table_counts": {"users": 8164, "course_classes": 599, "registrations": 4103, "auth_sessions": 5835}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c5: {"results": [{"body_mb": 10, "status": 401, "seconds": 0.6, "rss_before_mb": 47.1, "rss_peak_mb": 99.7}, {"body_mb": 100, "status": 401, "seconds": 2.8, "rss_before_mb": 99.7, "rss_peak_mb": 718.3}], "status": "FINDING", "baseline": {"p50_s": 0.007194654000159062, "p95_s": 0.013464612999996461}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.12, "read_p95_s": 0.008991044000140391, "threshold_s": 0.040393838999989384, "api_footprint": {"rss_mb": 723.9, "fds": 9, "threads": 6}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:54:10.490522+00:00", "table_counts": {"users": 8164, "course_classes": 599, "registrations": 4103, "auth_sessions": 5835}, "violation_counts": {}, "violations": {}}, "api_running": true}

## Toàn vẹn dữ liệu
Đã lưu 422 snapshot trước cleanup; không reseed giữa bài.
- Mọi snapshot đã lưu đều đạt; cần xem trạng thái nhóm để biết case nào chưa thực thi.

## Logs
- API: 13715 dòng 5xx; nguyên nhân: {'context canceled': 144797, 'timeout: context already done: context canceled': 179, 'failed to deallocate cached statement(s): context canceled': 5, 'write failed: write tcp 127.0.0.1:44044->127.0.0.1:5432: i/o timeout': 1, 'write failed: write tcp 127.0.0.1:44796->127.0.0.1:5432: i/o timeout': 1, 'timeout: read tcp 127.0.0.1:43386->127.0.0.1:5432: i/o timeout': 1, 'timeout: read tcp 127.0.0.1:42500->127.0.0.1:5432: i/o timeout': 1, 'timeout: read tcp 127.0.0.1:49924->127.0.0.1:5432: i/o timeout': 1, 'timeout: read tcp 127.0.0.1:43370->127.0.0.1:5432: i/o timeout': 1}.
- api.log được giữ nguyên. Client ngắt kết nối khi hết timeout có thể gây context canceled; cần đối chiếu thời điểm trước khi quy 5xx cho server bão hòa.
- postgresql-16-main.log: 0 dòng deadlock sau khi ghi nhận môi trường.
