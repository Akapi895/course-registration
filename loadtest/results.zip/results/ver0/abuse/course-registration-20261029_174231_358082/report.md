# Kết quả kiểm thử Phase 1

PASS/FAIL dựa trên ngưỡng bài thử, chưa phải SLA hiệu năng trong SRS.
INCONCLUSIVE: bằng chứng chưa đủ để kết luận năng lực hoặc tính đúng đắn.
FINDING: quan sát cần gia cố, không đồng nghĩa đã gây từ chối dịch vụ thành công.

## Môi trường
- cores: 4
- cpu_model: Intel(R) Xeon(R) CPU @ 2.20GHz
- server_cpus: 0,1
- attacker_cpus: 2,3
- cpu_isolated: True
- postgres_version: 16.15 (Ubuntu 16.15-1.pgdg24.04+2)
- python: 3.13.15
- load_students: 200
- api_config: {'JWT_TTL': '4h', 'SESSION_TTL': '4h', 'ADMIN_JWT_TTL': '8h', 'LOGIN_COOLDOWN': '20m', 'MAX_CREDITS': '26'}
- commit: 669e485752f3d524036089daab43f5ed1a493ff6
- api_sha256: e4a93c76d62e7895e1408fc2dff5de7af350d9a14b41062dfc79631b88f24d29

## Trạng thái thực thi
- perf: CHƯA CHẠY
- race: CHƯA CHẠY
- abuse: COMPLETED
- window: CHƯA CHẠY

## Đồng thời

## Chống chịu
- c1: {"failed_logins_per_s": 5.3, "reader_baseline_p95_s": 0.008517716000028486, "reader_under_flood_p95_s": 1.3434471200000075, "reader_requests": 26, "login_statuses": {"401": 80}, "reader_errors": {}, "status": "FAIL", "baseline": {"p50_s": 0.004192211999964002, "p95_s": 0.01073928200003138}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.06, "read_p95_s": 0.0038416360000042005, "threshold_s": 0.03221784600009414, "api_footprint": {"rss_mb": 47.8, "fds": 31, "threads": 6}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T17:45:32.867807+00:00", "table_counts": {"users": 302, "course_classes": 123, "registrations": 303, "auth_sessions": 282}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c2: {"requests_per_s": 688.4, "/health 200": 3442, "/api/classes 401": 3442, "/api/missing 404": 3442, "status": "PASS", "baseline": {"p50_s": 0.0037499860000025365, "p95_s": 0.01005884099998866}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.06, "read_p95_s": 0.0038628490000292004, "threshold_s": 0.030176522999965982, "api_footprint": {"rss_mb": 47.6, "fds": 12, "threads": 5}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T17:45:52.793253+00:00", "table_counts": {"users": 302, "course_classes": 123, "registrations": 303, "auth_sessions": 282}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c3: {"requested": 1000, "opened": 1000, "open_after_hold": 1000, "hold_s": 60, "fresh_request_status": 200, "fresh_request_s": 0.034, "api_before": {"rss_mb": 40.9, "fds": 9, "threads": 6}, "api_while_held": {"rss_mb": 50.2, "fds": 1009, "threads": 6}, "status": "FINDING", "baseline": {"p50_s": 0.0037187290000133544, "p95_s": 0.010207906000005096}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.07, "read_p95_s": 0.004085648999989644, "threshold_s": 0.030623718000015288, "api_footprint": {"rss_mb": 53.1, "fds": 9, "threads": 6}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T17:46:57.661456+00:00", "table_counts": {"users": 302, "course_classes": 123, "registrations": 303, "auth_sessions": 282}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c4: {"requested": 100, "opened": 100, "open_after_hold": 100, "hold_s": 30, "fresh_request_status": 200, "fresh_request_s": 0.034, "api_before": {"rss_mb": 40.6, "fds": 9, "threads": 5}, "api_while_held": {"rss_mb": 42.1, "fds": 109, "threads": 5}, "status": "FINDING", "baseline": {"p50_s": 0.004480265999973199, "p95_s": 0.010166291000018646}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.07, "read_p95_s": 0.003854776000025595, "threshold_s": 0.030498873000055937, "api_footprint": {"rss_mb": 42.7, "fds": 9, "threads": 5}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T17:47:32.454492+00:00", "table_counts": {"users": 302, "course_classes": 123, "registrations": 303, "auth_sessions": 282}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c5: {"results": [{"body_mb": 10, "status": 401, "seconds": 0.8, "rss_before_mb": 40.9, "rss_peak_mb": 103.8}, {"body_mb": 100, "status": 401, "seconds": 3.4, "rss_before_mb": 103.8, "rss_peak_mb": 703.3}], "status": "FINDING", "baseline": {"p50_s": 0.003333408999992571, "p95_s": 0.010216840999987653}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.06, "read_p95_s": 0.004390606000015396, "threshold_s": 0.03065052299996296, "api_footprint": {"rss_mb": 626.1, "fds": 9, "threads": 6}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T17:47:41.392921+00:00", "table_counts": {"users": 302, "course_classes": 123, "registrations": 303, "auth_sessions": 282}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c6: {"statuses": {"nested_json": 400, "duplicate_ids": 400, "21_ids": 400, "huge_id": 200, "negative_id": 400, "unicode_username": 401, "non_numeric_path": 404}, "server_errors": 0, "status": "PASS", "baseline": {"p50_s": 0.003625197000019398, "p95_s": 0.010118759999954818}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.06, "read_p95_s": 0.004319881000014902, "threshold_s": 0.030356279999864455, "api_footprint": {"rss_mb": 43.2, "fds": 9, "threads": 6}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T17:47:46.213107+00:00", "table_counts": {"users": 302, "course_classes": 123, "registrations": 303, "auth_sessions": 282}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c7: {"requests_per_s": 314.1, "p50_s": 0.5670571489999929, "p95_s": 1.2610469759999887, "p99_s": 1.668897998000034, "statuses": {"200": 4712}, "status": "PASS", "baseline": {"p50_s": 0.003651289000003999, "p95_s": 0.010723966999989898}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.06, "read_p95_s": 0.00381011500007844, "threshold_s": 0.032171900999969694, "api_footprint": {"rss_mb": 50.5, "fds": 16, "threads": 6}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T17:48:06.496193+00:00", "table_counts": {"users": 302, "course_classes": 123, "registrations": 303, "auth_sessions": 282}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c8: {"attempts": 89, "attempts_per_s": 4.5, "statuses": {"401": 89}, "login_after_attempts_status": 200, "status": "FINDING", "baseline": {"p50_s": 0.004592690999970728, "p95_s": 0.01273552700001801}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.08, "read_p95_s": 0.0062063929999567335, "threshold_s": 0.03820658100005403, "api_footprint": {"rss_mb": 43.0, "fds": 19, "threads": 5}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T17:48:32.602013+00:00", "table_counts": {"users": 302, "course_classes": 123, "registrations": 303, "auth_sessions": 283}, "violation_counts": {}, "violations": {}}, "api_running": true}

## Toàn vẹn dữ liệu
Đã lưu 11 snapshot trước cleanup; không reseed giữa bài.
- Mọi snapshot đã lưu đều đạt; cần xem trạng thái nhóm để biết case nào chưa thực thi.

## Logs
- API: 0 dòng 5xx; nguyên nhân: {}.
- api.log được giữ nguyên. Client ngắt kết nối khi hết timeout có thể gây context canceled; cần đối chiếu thời điểm trước khi quy 5xx cho server bão hòa.
- postgresql-16-main.log: 0 dòng deadlock sau khi ghi nhận môi trường.
