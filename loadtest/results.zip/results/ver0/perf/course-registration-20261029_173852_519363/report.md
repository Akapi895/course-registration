# Kết quả kiểm thử Phase 1

PASS/FAIL dựa trên ngưỡng bài thử, chưa phải SLA hiệu năng trong SRS.
INCONCLUSIVE: bằng chứng chưa đủ để kết luận năng lực hoặc tính đúng đắn.
FINDING: quan sát cần gia cố, không đồng nghĩa đã gây từ chối dịch vụ thành công.

## Môi trường
- cores: 4
- cpu_model: Intel(R) Xeon(R) CPU @ 2.20GHz
- server_cpus: 0,1
- attacker_cpus: 2,3
- cpu_isolated: True
- postgres_version: 16.15 (Ubuntu 16.15-1.pgdg24.04+2)
- python: 3.13.15
- load_students: 4000
- api_config: {'JWT_TTL': '4h', 'SESSION_TTL': '4h', 'ADMIN_JWT_TTL': '8h', 'LOGIN_COOLDOWN': '20m', 'MAX_CREDITS': '26'}
- commit: 669e485752f3d524036089daab43f5ed1a493ff6
- api_sha256: e4a93c76d62e7895e1408fc2dff5de7af350d9a14b41062dfc79631b88f24d29

## Trạng thái thực thi
- perf: COMPLETED
- race: CHƯA CHẠY
- abuse: CHƯA CHẠY
- window: CHƯA CHẠY

## Hiệu năng
Ngưỡng: HTTP p95 ≤ 500.0 ms; lỗi HTTP/kết nối/giao thức và thao tác ≤ 1.0%.
Percentile được tính từ histogram gộp các worker (làm tròn lên 1 ms).
Tốc độ đến của bài đăng ký tính theo thao tác; mỗi thao tác có thể tạo nhiều request HTTP.

| case | status | accounts used | req/s | p95 ms | p99 ms | HTTP error % | operation error % | dropped |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| a1-baseline | PASS | 1 | 245.2 | 7 | 8 | 0.0 | 0.0 | 0 |
| a2-read-1000 | FAIL | 1000 | 520.68 | 1515 | 1612 | 0.0 | 0.0 | 0 |
| a2-read-200 | PASS | 200 | 198.5 | 17 | 25 | 0.0 | 0.0 | 0 |
| a2-read-2000 | FAIL | 2000 | 503.0 | 4560 | 4731 | 0.0 | 0.0 | 0 |
| a2-read-3000 | FAIL | 3000 | 479.95 | 7724 | 8006 | 0.0 | 0.0 | 0 |
| a2-read-4000 | FAIL | 4000 | 473.4 | 10007 | 10131 | 7.147 | 7.147 | 0 |
| a2-read-500 | PASS | 500 | 484.93 | 74 | 100 | 0.0 | 0.0 | 0 |
| a3-small-1000 | PASS | 1000 | 908.32 | 197 | 280 | 0.0 | 0.0 | 0 |
| a3-small-200 | PASS | 200 | 248.15 | 26 | 37 | 0.0 | 0.0 | 0 |
| a3-small-2000 | FAIL | 2000 | 1004.28 | 1126 | 1223 | 0.0 | 0.0 | 0 |
| a3-small-3000 | FAIL | 3000 | 996.67 | 2140 | 2280 | 0.0 | 0.0 | 0 |
| a3-small-4000 | FAIL | 4000 | 996.13 | 3159 | 3198 | 0.0 | 0.0 | 0 |
| a3-small-500 | PASS | 500 | 568.07 | 46 | 67 | 0.0 | 0.0 | 0 |
| a3-wide-1000 | FAIL | 1000 | 341.03 | 7806 | 8118 | 0.0 | 0.0 | 0 |
| a3-wide-200 | FAIL | 200 | 340.93 | 1442 | 1827 | 0.0 | 0.0 | 0 |
| a3-wide-2000 | FAIL | 2000 | 379.85 | 9480 | 10002 | 2.225 | 100.0 | 0 |
| a3-wide-3000 | FAIL | 3000 | 340.27 | 10735 | 10805 | 35.555 | 100.0 | 0 |
| a3-wide-4000 | FAIL | 4000 | 344.57 | 10787 | 10839 | 92.657 | 100.0 | 0 |
| a3-wide-500 | FAIL | 500 | 357.37 | 3567 | 3836 | 0.0 | 0.0 | 0 |
| a4-read-rate-100 | PASS | 4000 | 100.0 | 7 | 10 | 0.0 | 0.0 | 0 |
| a4-read-rate-200 | PASS | 4000 | 200.0 | 10 | 15 | 0.0 | 0.0 | 0 |
| a4-read-rate-400 | PASS | 4000 | 400.0 | 33 | 51 | 0.0 | 0.0 | 0 |
| a4-read-rate-800 | INCONCLUSIVE | 4000 | 472.42 | 8339 | 8537 | 0.0 | 0.0 | 19654 |
| a4-registration-rate-100 | INCONCLUSIVE | 4000 | 252.25 | 10003 | 10004 | 23.938 | 88.526 | 4 |
| a4-registration-rate-25 | PASS | 1500 | 150.02 | 34 | 43 | 0.0 | 0.0 | 0 |
| a4-registration-rate-50 | PASS | 3000 | 300.12 | 40 | 56 | 0.0 | 0.0 | 0 |
| a5-read-spike | FAIL | 4000 | 370.0 | 9475 | 9681 | 0.0 | 0.0 | 0 |
| a5-recovery | PASS | 10 | 48.72 | 9 | 11 | 0.0 | 0.0 | 0 |
| a5-registration-burst-4000-30s | INCONCLUSIVE | 3998 | 292.16 | 10003 | 10004 | 26.985 | 61.131 | 2 |
| a5-registration-burst-4000-5s | FAIL | 4000 | 672.83 | 10006 | 10026 | 97.374 | 98.275 | 0 |
| a6-soak | FAIL | 500 | 390.61 | 2636 | 3086 | 0.0 | 0.0 | 0 |
| a7-admin-login-16 | FAIL | 16 | 6.25 | 2997 | 3238 | 0.0 | 0.0 | 0 |
| a7-admin-login-4 | FAIL | 4 | 6.33 | 714 | 763 | 0.0 | 0.0 | 0 |
| a7-admin-login-64 | FAIL | 64 | 6.45 | 10020 | 10022 | 94.057 | 94.057 | 0 |
| a7-student-login-burst-4000 | FAIL | 4000 | 133.33 | 10003 | 10014 | 100.0 | 100.0 | 0 |

### Khoảng giới hạn đo được
- read: tốc độ đến lớn nhất quan sát còn đạt = 400 thao tác/s; mức không đạt phía trên = None thao tác/s.
  - Tại mức đó: throughput HTTP trung vị 400.00 req/s (khoảng 400.00–400.00); 1 lần đo.
  - Chưa xác nhận giới hạn: thiếu lần lặp, bậc không đạt phía trên hoặc năng lực bộ phát tải.
- registration: tốc độ đến lớn nhất quan sát còn đạt = 50 thao tác/s; mức không đạt phía trên = None thao tác/s.
  - Tại mức đó: throughput HTTP trung vị 300.12 req/s (khoảng 300.12–300.12); 1 lần đo.
  - Chưa xác nhận giới hạn: thiếu lần lặp, bậc không đạt phía trên hoặc năng lực bộ phát tải.

### Chi tiết theo case
- a1-baseline: PASS
  - business: {}; errors: {}
  - operation p95/p99: 9/10 ms; counters: {'issued': 14712, 'flow_completed': 14712, 'unfinished': 0}
  - resources: {'cpu': {'api': 33.25, 'postgres': 46.38, 'generator': 36.08}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 51.11, 'db_max_lock_waiters': 0, 'db_max_connections': 2, 'samples': 60, 'error': None}
- a2-read-1000: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 1519/1615 ms; counters: {'issued': 31241, 'flow_completed': 31241, 'unfinished': 0}
  - resources: {'cpu': {'api': 78.12, 'postgres': 117.22, 'generator': 113.8}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 114.27, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a2-read-200: PASS
  - business: {}; errors: {}
  - operation p95/p99: 20/28 ms; counters: {'issued': 11910, 'flow_completed': 11910, 'unfinished': 0}
  - resources: {'cpu': {'api': 28.56, 'postgres': 40.78, 'generator': 37.92}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 59.72, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a2-read-2000: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 4564/4734 ms; counters: {'issued': 30180, 'flow_completed': 30180, 'unfinished': 0}
  - resources: {'cpu': {'api': 78.82, 'postgres': 117.03, 'generator': 110.35}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 177.77, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a2-read-3000: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 7727/8009 ms; counters: {'issued': 28797, 'flow_completed': 28797, 'unfinished': 0}
  - resources: {'cpu': {'api': 82.73, 'postgres': 112.18, 'generator': 115.75}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 242.86, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a2-read-4000: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/classes: 0, original=timed out': 2030}
  - operation p95/p99: 10007/10131 ms; counters: {'issued': 28404, 'flow_completed': 26374, 'flow_failed': 2030, 'unfinished': 0}
  - resources: {'cpu': {'api': 81.03, 'postgres': 87.9, 'generator': 109.04}, 'generator_busy_fraction': 0.05172413793103448, 'api_peak_rss_mb': 304.14, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 58, 'error': None}
- a2-read-500: PASS
  - business: {}; errors: {}
  - operation p95/p99: 77/104 ms; counters: {'issued': 29096, 'flow_completed': 29096, 'unfinished': 0}
  - resources: {'cpu': {'api': 69.58, 'postgres': 111.32, 'generator': 103.65}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 74.37, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-small-1000: PASS
  - business: {'CLASS_FULL': 51860, 'registered': 1320}; errors: {}
  - operation p95/p99: 216/318 ms; counters: {'issued': 53180, 'flow_completed': 53180, 'unfinished': 0}
  - resources: {'cpu': {'api': 78.25, 'postgres': 97.88, 'generator': 71.73}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 114.28, 'db_max_lock_waiters': 3, 'db_max_connections': 5, 'samples': 59, 'error': None}
- a3-small-200: PASS
  - business: {'CLASS_FULL': 8629, 'registered': 3130}; errors: {}
  - operation p95/p99: 37/49 ms; counters: {'issued': 11759, 'flow_completed': 11759, 'unfinished': 0}
  - resources: {'cpu': {'api': 26.6, 'postgres': 34.4, 'generator': 19.81}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 200.47, 'db_max_lock_waiters': 3, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-small-2000: latency or HTTP/transport error threshold exceeded
  - business: {'CLASS_FULL': 59957, 'registered': 150}; errors: {}
  - operation p95/p99: 1128/1228 ms; counters: {'issued': 60107, 'flow_completed': 60107, 'unfinished': 0}
  - resources: {'cpu': {'api': 82.58, 'postgres': 103.92, 'generator': 78.07}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 167.63, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 58, 'error': None}
- a3-small-3000: latency or HTTP/transport error threshold exceeded
  - business: {'CLASS_FULL': 59653, 'registered': 72}; errors: {}
  - operation p95/p99: 2140/2282 ms; counters: {'issued': 59725, 'flow_completed': 59725, 'unfinished': 0}
  - resources: {'cpu': {'api': 84.09, 'postgres': 101.68, 'generator': 87.32}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 226.97, 'db_max_lock_waiters': 3, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-small-4000: latency or HTTP/transport error threshold exceeded
  - business: {'CLASS_FULL': 59669, 'registered': 51}; errors: {}
  - operation p95/p99: 3159/3198 ms; counters: {'issued': 59720, 'flow_completed': 59720, 'unfinished': 0}
  - resources: {'cpu': {'api': 85.48, 'postgres': 100.71, 'generator': 92.77}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 277.62, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-small-500: PASS
  - business: {'CLASS_FULL': 24176, 'registered': 4954}; errors: {}
  - operation p95/p99: 59/82 ms; counters: {'issued': 29130, 'flow_completed': 29130, 'unfinished': 0}
  - resources: {'cpu': {'api': 59.38, 'postgres': 74.66, 'generator': 46.77}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 93.24, 'db_max_lock_waiters': 3, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-wide-1000: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 20000}; errors: {}
  - operation p95/p99: 15636/15674 ms; counters: {'issued': 4000, 'flow_completed': 4000, 'unfinished': 0}
  - resources: {'cpu': {'api': 61.12, 'postgres': 91.61, 'generator': 26.5}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 123.79, 'db_max_lock_waiters': 1, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-wide-200: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 16560}; errors: {}
  - operation p95/p99: 3682/3834 ms; counters: {'issued': 3312, 'flow_completed': 3312, 'unfinished': 0}
  - resources: {'cpu': {'api': 61.35, 'postgres': 90.25, 'generator': 28.24}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 82.33, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-wide-2000: latency or HTTP/transport error threshold exceeded
  - business: {'ALREADY_REGISTERED': 23796, 'registered': 14149}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 507}
  - operation p95/p99: 14915/15069 ms; counters: {'issued': 8096, 'flow_failed': 8096, 'unfinished': 0}
  - resources: {'cpu': {'api': 65.84, 'postgres': 96.04, 'generator': 31.26}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 181.06, 'db_max_lock_waiters': 0, 'db_max_connections': 5, 'samples': 59, 'error': None}
- a3-wide-3000: latency or HTTP/transport error threshold exceeded
  - business: {'ALREADY_REGISTERED': 29431, 'registered': 7419}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 7259}
  - operation p95/p99: 14167/14688 ms; counters: {'issued': 14629, 'flow_failed': 14629, 'unfinished': 0}
  - resources: {'cpu': {'api': 68.3, 'postgres': 84.7, 'generator': 34.26}, 'generator_busy_fraction': 0.01694915254237288, 'api_peak_rss_mb': 235.21, 'db_max_lock_waiters': 1, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-wide-4000: latency or HTTP/transport error threshold exceeded
  - business: {'ALREADY_REGISTERED': 3214, 'registered': 1006}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 19156}
  - operation p95/p99: 10841/12349 ms; counters: {'issued': 20000, 'flow_failed': 20000, 'unfinished': 0}
  - resources: {'cpu': {'api': 72.68, 'postgres': 92.69, 'generator': 36.33}, 'generator_busy_fraction': 0.06779661016949153, 'api_peak_rss_mb': 291.07, 'db_max_lock_waiters': 1, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-wide-500: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 18045}; errors: {}
  - operation p95/p99: 7774/7833 ms; counters: {'issued': 3609, 'flow_completed': 3609, 'unfinished': 0}
  - resources: {'cpu': {'api': 61.9, 'postgres': 91.16, 'generator': 29.07}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 97.61, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-read-rate-100: PASS
  - business: {}; errors: {}
  - operation p95/p99: 9/13 ms; counters: {'scheduled': 6000, 'issued': 6000, 'flow_completed': 6000, 'unfinished': 0}
  - resources: {'cpu': {'api': 18.24, 'postgres': 18.8, 'generator': 22.35}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 183.01, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-read-rate-200: PASS
  - business: {}; errors: {}
  - operation p95/p99: 13/18 ms; counters: {'scheduled': 12000, 'issued': 12000, 'flow_completed': 12000, 'unfinished': 0}
  - resources: {'cpu': {'api': 36.26, 'postgres': 40.36, 'generator': 45.77}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 185.1, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-read-rate-400: PASS
  - business: {}; errors: {}
  - operation p95/p99: 36/54 ms; counters: {'scheduled': 24000, 'issued': 24000, 'flow_completed': 24000, 'unfinished': 0}
  - resources: {'cpu': {'api': 67.77, 'postgres': 89.45, 'generator': 96.07}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 196.53, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 58, 'error': None}
- a4-read-rate-800: generator dropped, failed or did not finish operations
  - business: {}; errors: {}
  - operation p95/p99: 8342/8540 ms; counters: {'scheduled': 48000, 'issued': 28345, 'dropped': 19654, 'scheduler_late': 119, 'flow_completed': 28345, 'unfinished': 0}
  - resources: {'cpu': {'api': 83.52, 'postgres': 112.34, 'generator': 124.88}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 293.0, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-registration-rate-100: generator dropped, failed or did not finish operations
  - business: {'registered': 5773, 'ALREADY_REGISTERED': 6092}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 3623}
  - operation p95/p99: 24965/25562 ms; counters: {'scheduled': 6000, 'issued': 5996, 'flow_failed': 5308, 'dropped': 4, 'scheduler_late': 4, 'flow_completed': 688, 'unfinished': 0}
  - resources: {'cpu': {'api': 62.81, 'postgres': 76.71, 'generator': 30.93}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 182.51, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-registration-rate-25: PASS
  - business: {'registered': 7500}; errors: {}
  - operation p95/p99: 85/104 ms; counters: {'scheduled': 1500, 'issued': 1500, 'flow_completed': 1500, 'unfinished': 0}
  - resources: {'cpu': {'api': 36.64, 'postgres': 43.77, 'generator': 14.89}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 153.38, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-registration-rate-50: PASS
  - business: {'registered': 15000}; errors: {}
  - operation p95/p99: 125/159 ms; counters: {'scheduled': 3000, 'issued': 3000, 'flow_completed': 3000, 'unfinished': 0}
  - resources: {'cpu': {'api': 57.97, 'postgres': 79.8, 'generator': 36.24}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 159.05, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a5-read-spike: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 9478/9684 ms; counters: {'issued': 35150, 'flow_completed': 35150, 'unfinished': 0}
  - resources: {'cpu': {'api': 64.08, 'postgres': 86.51, 'generator': 90.03}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 295.64, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 93, 'error': None}
- a5-recovery: PASS
  - business: {}; errors: {}
  - operation p95/p99: 11/13 ms; counters: {'issued': 2923, 'flow_completed': 2923, 'unfinished': 0}
  - resources: {'cpu': {'api': 8.22, 'postgres': 9.46, 'generator': 8.93}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 72.61, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a5-registration-burst-4000-30s: not all requested accounts issued a measured operation; generator dropped, failed or did not finish operations
  - business: {'registered': 7770}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 2444}
  - operation p95/p99: 26609/27599 ms; counters: {'scheduled': 4000, 'issued': 3998, 'flow_completed': 1554, 'flow_failed': 2444, 'dropped': 2, 'scheduler_late': 2, 'unfinished': 0}
  - resources: {'cpu': {'api': 63.89, 'postgres': 93.15, 'generator': 37.27}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 220.0, 'db_max_lock_waiters': 1, 'db_max_connections': 4, 'samples': 30, 'error': None}
- a5-registration-burst-4000-5s: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 345}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 3931}
  - operation p95/p99: 10015/15402 ms; counters: {'scheduled': 4000, 'issued': 4000, 'flow_failed': 3931, 'flow_completed': 69, 'unfinished': 0}
  - resources: {'cpu': {'api': 69.05, 'postgres': 93.2, 'generator': 79.6}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 203.5, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 6, 'error': None}
- a6-soak: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 117375}; errors: {}
  - operation p95/p99: 6919/7715 ms; counters: {'issued': 116938, 'flow_completed': 116938, 'unfinished': 0}
  - resources: {'cpu': {'api': 66.28, 'postgres': 97.39, 'generator': 54.54}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 94.57, 'db_max_lock_waiters': 1, 'db_max_connections': 5, 'samples': 594, 'error': None}
- a7-admin-login-16: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 2997/3238 ms; counters: {'issued': 375, 'flow_completed': 375, 'unfinished': 0}
  - resources: {'cpu': {'api': 198.69, 'postgres': 0.8, 'generator': 0.53}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 44.33, 'db_max_lock_waiters': 2, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a7-admin-login-4: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 714/764 ms; counters: {'issued': 380, 'flow_completed': 380, 'unfinished': 0}
  - resources: {'cpu': {'api': 198.94, 'postgres': 0.71, 'generator': 0.56}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 91.72, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a7-admin-login-64: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/auth/login: 0, original=timed out': 364}
  - operation p95/p99: 10020/10022 ms; counters: {'issued': 387, 'flow_completed': 23, 'flow_failed': 364, 'unfinished': 0}
  - resources: {'cpu': {'api': 198.78, 'postgres': 0.31, 'generator': 0.49}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 50.96, 'db_max_lock_waiters': 3, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a7-student-login-burst-4000: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/auth/login: 0, original=timed out': 4000}
  - operation p95/p99: 10003/10014 ms; counters: {'scheduled': 4000, 'issued': 4000, 'flow_failed': 4000, 'unfinished': 0}
  - resources: {'cpu': {'api': 194.17, 'postgres': 0.33, 'generator': 36.48}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 133.42, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 15, 'error': None}

## Đồng thời

## Chống chịu

## Toàn vẹn dữ liệu
Đã lưu 38 snapshot trước cleanup; không reseed giữa bài.
- Mọi snapshot đã lưu đều đạt; cần xem trạng thái nhóm để biết case nào chưa thực thi.

## Logs
- API: 5186 dòng 5xx; nguyên nhân: {'context canceled': 106266, 'timeout: context already done: context canceled': 107, 'failed to deallocate cached statement(s): context canceled': 1, 'write failed: write tcp 127.0.0.1:57388->127.0.0.1:5432: i/o timeout': 1, 'write failed: write tcp 127.0.0.1:52268->127.0.0.1:5432: i/o timeout': 1}.
- api.log được giữ nguyên. Client ngắt kết nối khi hết timeout có thể gây context canceled; cần đối chiếu thời điểm trước khi quy 5xx cho server bão hòa.
- postgresql-16-main.log: 0 dòng deadlock sau khi ghi nhận môi trường.
