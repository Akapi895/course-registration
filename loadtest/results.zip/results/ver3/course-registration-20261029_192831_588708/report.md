# Kết quả kiểm thử Phase 1

PASS/FAIL dựa trên ngưỡng bài thử, chưa phải SLA hiệu năng trong SRS.
INCONCLUSIVE: bằng chứng chưa đủ để kết luận năng lực hoặc tính đúng đắn.
FINDING: quan sát cần gia cố, không đồng nghĩa đã gây từ chối dịch vụ thành công.

## Môi trường
- cores: 4
- cpu_model: AMD EPYC 7B12
- server_cpus: 0,1
- attacker_cpus: 2,3
- cpu_isolated: True
- postgres_version: 16.15 (Ubuntu 16.15-1.pgdg24.04+2)
- python: 3.13.15
- load_students: 4000
- api_config: {'JWT_TTL': '4h', 'SESSION_TTL': '4h', 'ADMIN_JWT_TTL': '8h', 'LOGIN_COOLDOWN': '20m', 'MAX_CREDITS': '26'}
- commit: 669e485752f3d524036089daab43f5ed1a493ff6
- api_sha256: e4a93c76d62e7895e1408fc2dff5de7af350d9a14b41062dfc79631b88f24d29

## Trạng thái thực thi
- perf: COMPLETED
- race: COMPLETED
- abuse: ERROR — RuntimeError: API exited with 1:
127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:34 | 200 |    3.4ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:34 | 200 |   3.19ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |  35.51µs |       127.0.0.1 | GET      "/health"
[GIN] 2026/10/29 - 20:57:35 | 200 | 52.529µs |       127.0.0.1 | GET      "/health"
[GIN] 2026/10/29 - 20:57:35 | 200 |    7.8ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   4.91ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   4.17ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   5.36ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   6.04ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |    4.2ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   4.55ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   4.34ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   4.38ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |    3.9ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   3.95ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   3.99ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   3.88ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |      4ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   3.92ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   4.84ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   4.99ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   3.86ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   3.45ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:35 | 200 |   3.73ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:36 | 401 | 415.95ms |       127.0.0.1 | POST     "/api/auth/login"
[GIN] 2026/10/29 - 20:57:38 | 401 |    2.04s |       127.0.0.1 | POST     "/api/auth/login"
[GIN] 2026/10/29 - 20:57:38 | 200 |  16.67µs |       127.0.0.1 | GET      "/health"
[GIN] 2026/10/29 - 20:57:38 | 200 |   4.27ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:38 | 200 |   4.27ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:38 | 200 |   3.76ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:38 | 200 |   3.99ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:38 | 200 |    4.7ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:39 | 200 |  16.42µs |       127.0.0.1 | GET      "/health"
[GIN] 2026/10/29 - 20:57:39 | 200 |   4.47ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:39 | 200 |   3.42ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:39 | 200 |   4.47ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:39 | 200 |   4.31ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:39 | 200 |   3.81ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:40 | 200 |  13.92µs |       127.0.0.1 | GET      "/health"
[GIN] 2026/10/29 - 20:57:40 | 200 |    4.9ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:40 | 200 |   3.73ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:40 | 200 |   3.74ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:40 | 200 |   3.61ms |       127.0.0.1 | GET      "/api/classes"
[GIN] 2026/10/29 - 20:57:40 | 200 |   3.53ms |       127.0.0.1 | GET      "/api/classes"
2026/10/29 20:57:40 listen tcp :8080: bind: address already in use

- window: ERROR — ConnectError: [Errno 111] Connection refused

## Hiệu năng
Ngưỡng: HTTP p95 ≤ 500.0 ms; lỗi HTTP/kết nối/giao thức và thao tác ≤ 1.0%.
Percentile được tính từ histogram gộp các worker (làm tròn lên 1 ms).
Tốc độ đến của bài đăng ký tính theo thao tác; mỗi thao tác có thể tạo nhiều request HTTP.

| case | status | accounts used | req/s | p95 ms | p99 ms | HTTP error % | operation error % | dropped |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| a1-baseline | PASS | 1 | 382.12 | 5 | 6 | 0.0 | 0.0 | 0 |
| a2-read-1000 | PASS | 1000 | 780.55 | 450 | 497 | 0.0 | 0.0 | 0 |
| a2-read-200 | PASS | 200 | 200.0 | 13 | 19 | 0.0 | 0.0 | 0 |
| a2-read-2000 | FAIL | 2000 | 762.1 | 2537 | 2633 | 0.0 | 0.0 | 0 |
| a2-read-3000 | FAIL | 3000 | 727.5 | 3985 | 4132 | 0.0 | 0.0 | 0 |
| a2-read-4000 | FAIL | 4000 | 728.13 | 6659 | 6809 | 0.0 | 0.0 | 0 |
| a2-read-500 | PASS | 500 | 495.57 | 18 | 29 | 0.0 | 0.0 | 0 |
| a3-small-1000 | PASS | 1000 | 1027.03 | 54 | 64 | 0.0 | 0.0 | 0 |
| a3-small-200 | PASS | 200 | 247.4 | 22 | 25 | 0.0 | 0.0 | 0 |
| a3-small-2000 | FAIL | 2000 | 1243.37 | 675 | 691 | 0.0 | 0.0 | 0 |
| a3-small-3000 | FAIL | 3000 | 1217.97 | 1532 | 1579 | 0.0 | 0.0 | 0 |
| a3-small-4000 | FAIL | 4000 | 1189.33 | 2427 | 2526 | 0.0 | 0.0 | 0 |
| a3-small-500 | PASS | 500 | 611.62 | 23 | 28 | 0.0 | 0.0 | 0 |
| a3-wide-1000 | FAIL | 1000 | 424.17 | 6285 | 6517 | 0.0 | 0.0 | 0 |
| a3-wide-200 | FAIL | 200 | 431.05 | 1089 | 1168 | 0.0 | 0.0 | 0 |
| a3-wide-2000 | FAIL | 2000 | 456.2 | 7859 | 8377 | 0.0 | 98.675 | 0 |
| a3-wide-3000 | FAIL | 3000 | 402.03 | 10002 | 10570 | 7.3 | 100.0 | 0 |
| a3-wide-4000 | FAIL | 4000 | 392.75 | 10630 | 10761 | 65.449 | 100.0 | 0 |
| a3-wide-500 | FAIL | 500 | 437.38 | 2896 | 3074 | 0.0 | 0.0 | 0 |
| a4-read-rate-100 | PASS | 4000 | 100.0 | 6 | 7 | 0.0 | 0.0 | 0 |
| a4-read-rate-200 | PASS | 4000 | 200.0 | 6 | 7 | 0.0 | 0.0 | 0 |
| a4-read-rate-400 | PASS | 4000 | 400.0 | 9 | 15 | 0.0 | 0.0 | 0 |
| a4-read-rate-800 | INCONCLUSIVE | 4000 | 739.75 | 5172 | 5403 | 0.0 | 0.0 | 3614 |
| a4-registration-rate-100 | FAIL | 4000 | 397.93 | 10002 | 10002 | 8.385 | 35.117 | 0 |
| a4-registration-rate-200 | INCONCLUSIVE | 4000 | 299.1 | 10002 | 10004 | 37.903 | 99.973 | 794 |
| a4-registration-rate-25 | PASS | 1500 | 149.97 | 20 | 22 | 0.0 | 0.0 | 0 |
| a4-registration-rate-50 | PASS | 3000 | 299.97 | 23 | 27 | 0.0 | 0.0 | 0 |
| a4-registration-rate-50-repeat-2 | PASS | 3000 | 300.0 | 23 | 27 | 0.0 | 0.0 | 0 |
| a4-registration-rate-50-repeat-3 | PASS | 3000 | 300.02 | 23 | 27 | 0.0 | 0.0 | 0 |
| a4-registration-rate-75-repeat-2 | PASS | 4000 | 450.02 | 63 | 119 | 0.0 | 0.0 | 0 |
| a4-registration-rate-75-repeat-3 | PASS | 4000 | 450.02 | 227 | 362 | 0.0 | 0.0 | 0 |
| a4-registration-refine-75 | FAIL | 4000 | 442.93 | 920 | 1066 | 0.0 | 0.0 | 0 |
| a5-read-spike | FAIL | 4000 | 525.64 | 6041 | 6280 | 0.0 | 0.0 | 0 |
| a5-recovery | PASS | 10 | 48.9 | 7 | 9 | 0.0 | 0.0 | 0 |
| a5-registration-burst-4000-30s | FAIL | 4000 | 380.19 | 10002 | 10003 | 15.145 | 44.625 | 0 |
| a5-registration-burst-4000-5s | FAIL | 4000 | 683.83 | 10003 | 10016 | 93.931 | 96.35 | 0 |
| a6-soak | FAIL | 500 | 536.94 | 1499 | 1609 | 0.0 | 0.0 | 0 |
| a7-admin-login-16 | FAIL | 16 | 7.6 | 2509 | 2641 | 0.0 | 0.0 | 0 |
| a7-admin-login-4 | FAIL | 4 | 7.6 | 600 | 624 | 0.0 | 0.0 | 0 |
| a7-admin-login-64 | FAIL | 64 | 8.02 | 9680 | 9830 | 0.0 | 0.0 | 0 |
| a7-student-login-burst-4000 | FAIL | 4000 | 133.33 | 10002 | 10008 | 100.0 | 100.0 | 0 |

### Khoảng giới hạn đo được
- read: tốc độ đến lớn nhất quan sát còn đạt = 400 thao tác/s; mức không đạt phía trên = None thao tác/s.
  - Tại mức đó: throughput HTTP trung vị 400.00 req/s (khoảng 400.00–400.00); 1 lần đo.
  - Chưa xác nhận giới hạn: thiếu lần lặp, bậc không đạt phía trên hoặc năng lực bộ phát tải.
- registration: tốc độ đến lớn nhất quan sát còn đạt = 50 thao tác/s; mức không đạt phía trên = 100 thao tác/s.
  - Tại mức đó: throughput HTTP trung vị 300.00 req/s (khoảng 299.97–300.02); 3 lần đo.
  - Chưa xác nhận giới hạn: thiếu lần lặp, bậc không đạt phía trên hoặc năng lực bộ phát tải.

### Chi tiết theo case
- a1-baseline: PASS
  - business: {}; errors: {}
  - operation p95/p99: 6/7 ms; counters: {'issued': 22927, 'flow_completed': 22927, 'unfinished': 0}
  - resources: {'cpu': {'api': 35.06, 'postgres': 49.93, 'generator': 32.48}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 50.71, 'db_max_lock_waiters': 0, 'db_max_connections': 2, 'samples': 60, 'error': None}
- a2-read-1000: PASS
  - business: {}; errors: {}
  - operation p95/p99: 452/498 ms; counters: {'issued': 46833, 'flow_completed': 46833, 'unfinished': 0}
  - resources: {'cpu': {'api': 76.61, 'postgres': 118.03, 'generator': 97.77}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 100.39, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a2-read-200: PASS
  - business: {}; errors: {}
  - operation p95/p99: 15/20 ms; counters: {'issued': 12000, 'flow_completed': 12000, 'unfinished': 0}
  - resources: {'cpu': {'api': 19.45, 'postgres': 28.18, 'generator': 22.79}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 59.91, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a2-read-2000: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 2539/2634 ms; counters: {'issued': 45726, 'flow_completed': 45726, 'unfinished': 0}
  - resources: {'cpu': {'api': 79.4, 'postgres': 116.41, 'generator': 95.69}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 175.41, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a2-read-3000: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 3987/4134 ms; counters: {'issued': 43650, 'flow_completed': 43650, 'unfinished': 0}
  - resources: {'cpu': {'api': 81.47, 'postgres': 114.21, 'generator': 101.36}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 237.97, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a2-read-4000: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 6661/6811 ms; counters: {'issued': 43688, 'flow_completed': 43688, 'unfinished': 0}
  - resources: {'cpu': {'api': 83.65, 'postgres': 111.63, 'generator': 103.48}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 305.25, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a2-read-500: PASS
  - business: {}; errors: {}
  - operation p95/p99: 19/30 ms; counters: {'issued': 29734, 'flow_completed': 29734, 'unfinished': 0}
  - resources: {'cpu': {'api': 49.32, 'postgres': 71.95, 'generator': 58.69}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 71.57, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a3-small-1000: PASS
  - business: {'CLASS_FULL': 53885, 'registered': 3868}; errors: {}
  - operation p95/p99: 67/94 ms; counters: {'issued': 57753, 'flow_completed': 57753, 'unfinished': 0}
  - resources: {'cpu': {'api': 78.58, 'postgres': 89.21, 'generator': 48.98}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 113.72, 'db_max_lock_waiters': 3, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-small-200: PASS
  - business: {'CLASS_FULL': 8756, 'registered': 3044}; errors: {}
  - operation p95/p99: 33/41 ms; counters: {'issued': 11800, 'flow_completed': 11800, 'unfinished': 0}
  - resources: {'cpu': {'api': 23.2, 'postgres': 27.86, 'generator': 12.86}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 182.84, 'db_max_lock_waiters': 3, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a3-small-2000: latency or HTTP/transport error threshold exceeded
  - business: {'CLASS_FULL': 74110, 'registered': 246}; errors: {}
  - operation p95/p99: 675/691 ms; counters: {'issued': 74356, 'flow_completed': 74356, 'unfinished': 0}
  - resources: {'cpu': {'api': 88.05, 'postgres': 100.1, 'generator': 61.1}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 164.73, 'db_max_lock_waiters': 3, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-small-3000: latency or HTTP/transport error threshold exceeded
  - business: {'CLASS_FULL': 72874, 'registered': 102}; errors: {}
  - operation p95/p99: 1532/1579 ms; counters: {'issued': 72976, 'flow_completed': 72976, 'unfinished': 0}
  - resources: {'cpu': {'api': 89.29, 'postgres': 98.07, 'generator': 71.88}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 221.93, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-small-4000: latency or HTTP/transport error threshold exceeded
  - business: {'CLASS_FULL': 71234, 'registered': 63}; errors: {}
  - operation p95/p99: 2427/2526 ms; counters: {'issued': 71297, 'flow_completed': 71297, 'unfinished': 0}
  - resources: {'cpu': {'api': 90.22, 'postgres': 96.84, 'generator': 77.39}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 278.18, 'db_max_lock_waiters': 3, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-small-500: PASS
  - business: {'registered': 7259, 'CLASS_FULL': 22179}; errors: {}
  - operation p95/p99: 34/44 ms; counters: {'issued': 29438, 'flow_completed': 29438, 'unfinished': 0}
  - resources: {'cpu': {'api': 56.37, 'postgres': 66.67, 'generator': 31.01}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 90.03, 'db_max_lock_waiters': 3, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a3-wide-1000: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 20000}; errors: {}
  - operation p95/p99: 12558/12590 ms; counters: {'issued': 4000, 'flow_completed': 4000, 'unfinished': 0}
  - resources: {'cpu': {'api': 68.48, 'postgres': 92.02, 'generator': 19.88}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 122.24, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a3-wide-200: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 20865}; errors: {}
  - operation p95/p99: 2375/2396 ms; counters: {'issued': 4173, 'flow_completed': 4173, 'unfinished': 0}
  - resources: {'cpu': {'api': 65.84, 'postgres': 89.0, 'generator': 21.4}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 80.77, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a3-wide-2000: latency or HTTP/transport error threshold exceeded
  - business: {'ALREADY_REGISTERED': 36752, 'registered': 16473}; errors: {}
  - operation p95/p99: 11886/16223 ms; counters: {'issued': 10645, 'flow_failed': 10504, 'unfinished': 0, 'flow_completed': 141}
  - resources: {'cpu': {'api': 73.0, 'postgres': 96.61, 'generator': 22.46}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 179.16, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a3-wide-3000: latency or HTTP/transport error threshold exceeded
  - business: {'ALREADY_REGISTERED': 43528, 'registered': 11397}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 1761}
  - operation p95/p99: 13205/15390 ms; counters: {'issued': 12746, 'flow_failed': 12746, 'unfinished': 0}
  - resources: {'cpu': {'api': 73.64, 'postgres': 94.41, 'generator': 25.66}, 'generator_busy_fraction': 0.01694915254237288, 'api_peak_rss_mb': 233.17, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-wide-4000: latency or HTTP/transport error threshold exceeded
  - business: {'ALREADY_REGISTERED': 18215, 'registered': 4670}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 15423}
  - operation p95/p99: 12903/13250 ms; counters: {'issued': 20000, 'flow_failed': 20000, 'unfinished': 0}
  - resources: {'cpu': {'api': 74.7, 'postgres': 92.73, 'generator': 29.46}, 'generator_busy_fraction': 0.01694915254237288, 'api_peak_rss_mb': 289.88, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a3-wide-500: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 22550}; errors: {}
  - operation p95/p99: 6265/6330 ms; counters: {'issued': 4510, 'flow_completed': 4510, 'unfinished': 0}
  - resources: {'cpu': {'api': 68.14, 'postgres': 92.25, 'generator': 21.84}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 95.96, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a4-read-rate-100: PASS
  - business: {}; errors: {}
  - operation p95/p99: 7/9 ms; counters: {'scheduled': 6000, 'issued': 6000, 'flow_completed': 6000, 'unfinished': 0}
  - resources: {'cpu': {'api': 12.53, 'postgres': 14.0, 'generator': 14.19}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 181.59, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a4-read-rate-200: PASS
  - business: {}; errors: {}
  - operation p95/p99: 7/9 ms; counters: {'scheduled': 12000, 'issued': 12000, 'flow_completed': 12000, 'unfinished': 0}
  - resources: {'cpu': {'api': 23.58, 'postgres': 26.44, 'generator': 26.87}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 183.36, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-read-rate-400: PASS
  - business: {}; errors: {}
  - operation p95/p99: 10/16 ms; counters: {'scheduled': 24000, 'issued': 24000, 'flow_completed': 24000, 'unfinished': 0}
  - resources: {'cpu': {'api': 45.28, 'postgres': 55.42, 'generator': 52.66}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 189.96, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-read-rate-800: generator dropped, failed or did not finish operations
  - business: {}; errors: {}
  - operation p95/p99: 5174/5405 ms; counters: {'scheduled': 48000, 'issued': 44385, 'dropped': 3614, 'scheduler_late': 8, 'flow_completed': 44385, 'unfinished': 0}
  - resources: {'cpu': {'api': 83.39, 'postgres': 111.53, 'generator': 110.56}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 266.98, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-registration-rate-100: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 19569, 'ALREADY_REGISTERED': 421}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 2002}
  - operation p95/p99: 24365/24406 ms; counters: {'scheduled': 6000, 'issued': 6000, 'flow_completed': 3893, 'flow_failed': 2107, 'unfinished': 0}
  - resources: {'cpu': {'api': 69.62, 'postgres': 89.42, 'generator': 28.73}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 228.05, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-registration-rate-200: generator dropped, failed or did not finish operations
  - business: {'ALREADY_REGISTERED': 16262, 'registered': 5758}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 6802}
  - operation p95/p99: 13603/16534 ms; counters: {'scheduled': 12000, 'issued': 11206, 'dropped': 794, 'scheduler_late': 68, 'flow_failed': 11203, 'flow_completed': 3, 'unfinished': 0}
  - resources: {'cpu': {'api': 68.78, 'postgres': 67.07, 'generator': 26.97}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 244.4, 'db_max_lock_waiters': 1, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-registration-rate-25: PASS
  - business: {'registered': 7500}; errors: {}
  - operation p95/p99: 43/46 ms; counters: {'scheduled': 1500, 'issued': 1500, 'flow_completed': 1500, 'unfinished': 0}
  - resources: {'cpu': {'api': 25.12, 'postgres': 28.95, 'generator': 8.23}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 122.34, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a4-registration-rate-50: PASS
  - business: {'registered': 15000}; errors: {}
  - operation p95/p99: 52/59 ms; counters: {'scheduled': 3000, 'issued': 3000, 'flow_completed': 3000, 'unfinished': 0}
  - resources: {'cpu': {'api': 50.59, 'postgres': 59.67, 'generator': 20.55}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 157.79, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a4-registration-rate-50-repeat-2: PASS
  - business: {'registered': 15000}; errors: {}
  - operation p95/p99: 53/60 ms; counters: {'scheduled': 3000, 'issued': 3000, 'flow_completed': 3000, 'unfinished': 0}
  - resources: {'cpu': {'api': 50.05, 'postgres': 59.3, 'generator': 20.63}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 160.67, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a4-registration-rate-50-repeat-3: PASS
  - business: {'registered': 15000}; errors: {}
  - operation p95/p99: 52/59 ms; counters: {'scheduled': 3000, 'issued': 3000, 'flow_completed': 3000, 'unfinished': 0}
  - resources: {'cpu': {'api': 50.73, 'postgres': 60.16, 'generator': 20.74}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 158.74, 'db_max_lock_waiters': 0, 'db_max_connections': 5, 'samples': 60, 'error': None}
- a4-registration-rate-75-repeat-2: PASS
  - business: {'registered': 22500}; errors: {}
  - operation p95/p99: 287/449 ms; counters: {'scheduled': 4500, 'issued': 4500, 'flow_completed': 4500, 'unfinished': 0}
  - resources: {'cpu': {'api': 67.92, 'postgres': 89.75, 'generator': 28.67}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 184.48, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 59, 'error': None}
- a4-registration-rate-75-repeat-3: PASS
  - business: {'registered': 22500}; errors: {}
  - operation p95/p99: 871/898 ms; counters: {'scheduled': 4500, 'issued': 4500, 'flow_completed': 4500, 'unfinished': 0}
  - resources: {'cpu': {'api': 68.66, 'postgres': 89.91, 'generator': 28.85}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 185.13, 'db_max_lock_waiters': 0, 'db_max_connections': 5, 'samples': 59, 'error': None}
- a4-registration-refine-75: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 22500}; errors: {}
  - operation p95/p99: 2572/2677 ms; counters: {'scheduled': 4500, 'issued': 4500, 'flow_completed': 4500, 'unfinished': 0}
  - resources: {'cpu': {'api': 68.71, 'postgres': 89.78, 'generator': 29.66}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 189.55, 'db_max_lock_waiters': 1, 'db_max_connections': 5, 'samples': 59, 'error': None}
- a5-read-spike: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 6043/6282 ms; counters: {'issued': 49936, 'flow_completed': 49936, 'unfinished': 0}
  - resources: {'cpu': {'api': 60.61, 'postgres': 81.84, 'generator': 75.33}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 296.16, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 94, 'error': None}
- a5-recovery: PASS
  - business: {}; errors: {}
  - operation p95/p99: 8/11 ms; counters: {'issued': 2934, 'flow_completed': 2934, 'unfinished': 0}
  - resources: {'cpu': {'api': 5.97, 'postgres': 7.45, 'generator': 5.78}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 72.14, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a5-registration-burst-4000-30s: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 11075}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 1785}
  - operation p95/p99: 24552/24685 ms; counters: {'scheduled': 4000, 'issued': 4000, 'flow_completed': 2215, 'flow_failed': 1785, 'unfinished': 0}
  - resources: {'cpu': {'api': 68.05, 'postgres': 86.74, 'generator': 26.47}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 225.74, 'db_max_lock_waiters': 1, 'db_max_connections': 4, 'samples': 31, 'error': None}
- a5-registration-burst-4000-5s: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 730}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/registrations: 0, original=timed out': 3854}
  - operation p95/p99: 10015/15441 ms; counters: {'scheduled': 4000, 'issued': 4000, 'flow_failed': 3854, 'flow_completed': 146, 'unfinished': 0}
  - resources: {'cpu': {'api': 66.17, 'postgres': 84.02, 'generator': 50.88}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 203.46, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 6, 'error': None}
- a6-soak: latency or HTTP/transport error threshold exceeded
  - business: {'registered': 161355}; errors: {}
  - operation p95/p99: 3730/3885 ms; counters: {'issued': 160808, 'flow_completed': 160808, 'unfinished': 0}
  - resources: {'cpu': {'api': 71.04, 'postgres': 97.38, 'generator': 43.81}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 91.72, 'db_max_lock_waiters': 1, 'db_max_connections': 4, 'samples': 596, 'error': None}
- a7-admin-login-16: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 2509/2641 ms; counters: {'issued': 456, 'flow_completed': 456, 'unfinished': 0}
  - resources: {'cpu': {'api': 199.15, 'postgres': 0.75, 'generator': 0.55}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 45.57, 'db_max_lock_waiters': 3, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a7-admin-login-4: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 600/624 ms; counters: {'issued': 456, 'flow_completed': 456, 'unfinished': 0}
  - resources: {'cpu': {'api': 199.26, 'postgres': 0.62, 'generator': 0.5}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 86.6, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a7-admin-login-64: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {}
  - operation p95/p99: 9680/9830 ms; counters: {'issued': 481, 'flow_completed': 481, 'unfinished': 0}
  - resources: {'cpu': {'api': 198.94, 'postgres': 0.68, 'generator': 0.5}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 47.57, 'db_max_lock_waiters': 3, 'db_max_connections': 4, 'samples': 60, 'error': None}
- a7-student-login-burst-4000: latency or HTTP/transport error threshold exceeded
  - business: {}; errors: {'RetriesExceeded: URL http://127.0.0.1:8080/api/auth/login: 0, original=timed out': 4000}
  - operation p95/p99: 10002/10008 ms; counters: {'scheduled': 4000, 'issued': 4000, 'flow_failed': 4000, 'unfinished': 0}
  - resources: {'cpu': {'api': 190.13, 'postgres': 0.2, 'generator': 20.39}, 'generator_busy_fraction': 0.0, 'api_peak_rss_mb': 132.64, 'db_max_lock_waiters': 0, 'db_max_connections': 4, 'samples': 15, 'error': None}

## Đồng thời
- b1: FAIL — B1 class capacity race; requested rounds=20
  - {"name": "B1 class capacity race", "levels": [{"parallelism": 8, "rounds": 20, "violations": 0, "errors": []}, {"parallelism": 32, "rounds": 20, "violations": 0, "errors": []}, {"parallelism": 80, "rounds": 20, "violations": 20, "errors": ["round 0: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 1: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 2: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 3: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 4: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 5: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 6: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 7: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 8: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 9: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 10: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 11: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 12: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 13: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 14: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 15: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 16: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 17: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 18: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it", "round 19: only 77/80 students have a schedule free of [{'day_of_week': 7, 'start_period': 1, 'end_period': 1, 'room': 'LOADTEST'}]; some real seeded registration overlaps it"]}], "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:40:47.119083+00:00", "table_counts": {"users": 8102, "course_classes": 579, "registrations": 4103, "auth_sessions": 5843}, "violation_counts": {}, "violations": {}}, "status": "FAIL", "rounds_requested": 20}
- b2: PASS — B2 duplicate registration race (same account); requested rounds=20
  - {"name": "B2 duplicate registration race (same account)", "levels": [{"parallelism": 8, "rounds": 20, "violations": 0, "errors": []}, {"parallelism": 32, "rounds": 20, "violations": 0, "errors": []}, {"parallelism": 128, "rounds": 20, "violations": 0, "errors": []}], "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:40:55.639315+00:00", "table_counts": {"users": 8102, "course_classes": 579, "registrations": 4103, "auth_sessions": 5843}, "violation_counts": {}, "violations": {}}, "status": "PASS", "rounds_requested": 20}
- b3: PASS — B3 credit limit race; requested rounds=20
  - {"name": "B3 credit limit race", "rounds": 20, "violations": 0, "errors": [], "note": "10 sections x 3 credits, limit 26", "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:40:57.663906+00:00", "table_counts": {"users": 8102, "course_classes": 579, "registrations": 4103, "auth_sessions": 5843}, "violation_counts": {}, "violations": {}}, "status": "PASS", "rounds_requested": 20}
- b4: PASS — B4 schedule conflict race (same account); requested rounds=20
  - {"name": "B4 schedule conflict race (same account)", "levels": [{"parallelism": 8, "rounds": 20, "violations": 0, "errors": []}, {"parallelism": 32, "rounds": 20, "violations": 0, "errors": []}, {"parallelism": 128, "rounds": 20, "violations": 0, "errors": []}], "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:41:06.921386+00:00", "table_counts": {"users": 8102, "course_classes": 579, "registrations": 4103, "auth_sessions": 5843}, "violation_counts": {}, "violations": {}}, "status": "PASS", "rounds_requested": 20}
- b5: PASS — B5 double-cancel race; requested rounds=20
  - {"name": "B5 double-cancel race", "rounds": 20, "violations": 0, "errors": [], "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:41:07.868517+00:00", "table_counts": {"users": 8102, "course_classes": 579, "registrations": 4103, "auth_sessions": 5843}, "violation_counts": {}, "violations": {}}, "status": "PASS", "rounds_requested": 20}
- b6: PASS — B6 admin cancel vs registration storm; requested rounds=20
  - {"name": "B6 admin cancel vs registration storm", "rounds": 10, "parallelism": 20, "violations": 0, "errors": [], "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:41:08.868254+00:00", "table_counts": {"users": 8102, "course_classes": 589, "registrations": 4103, "auth_sessions": 5843}, "violation_counts": {}, "violations": {}}, "status": "PASS", "rounds_requested": 20}
- b7: PASS — B7 admin update vs registration; requested rounds=20
  - {"name": "B7 admin update vs registration", "rounds": 10, "violations": 0, "errors": [], "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:41:09.837869+00:00", "table_counts": {"users": 8102, "course_classes": 599, "registrations": 4103, "auth_sessions": 5843}, "violation_counts": {}, "violations": {}}, "status": "PASS", "rounds_requested": 20}
- b8: FAIL — B8 concurrent first-time login; requested rounds=20
  - {"name": "B8 concurrent first-time login", "levels": [{"parallelism": 8, "student_rounds": 20, "student_violations": 0, "student_skipped": 0, "student_errors": [], "admin_rounds": 20, "admin_violations": 0, "admin_errors": []}, {"parallelism": 32, "student_rounds": 20, "student_violations": 0, "student_skipped": 0, "student_errors": [], "admin_rounds": 20, "admin_violations": 0, "admin_errors": []}, {"parallelism": 128, "student_rounds": 20, "student_violations": 20, "student_skipped": 0, "student_errors": ["round 0 (racelogin0972b47b416e): ok=1 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 1 (racelogin99ddd93d5fb6): ok=1 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 2 (racelogined683a9fdf46): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 3 (raceloginbc756b946a7a): ok=1 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 4 (racelogin69447e8330fc): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 5 (raceloginf2d2f4130b46): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 6 (raceloginbe449f3f6ed5): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 7 (racelogin6c7be9cb5121): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 8 (racelogin4aea7c6f35f1): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 9 (racelogincc3aa38a2227): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 10 (racelogin041d5117bd61): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 11 (raceloginee96a0088ad2): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 12 (racelogin0cf0dc78555b): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 13 (racelogin48298259e362): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 14 (racelogin7a46d781001c): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 15 (racelogin2ea473997899): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 16 (racelogin60d3918ff145): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 17 (racelogin17ead5e36108): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 18 (racelogin682e27704b4b): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 19 (raceloginb7fee751a76a): ok=0 bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']"], "admin_rounds": 20, "admin_violations": 20, "admin_errors": ["round 0: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 1: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 2: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 3: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 4: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 5: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 6: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 7: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 8: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 9: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 10: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 11: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 12: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 13: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 14: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 15: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 16: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 17: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 18: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']", "round 19: bad=['timed out', 'timed out', 'timed out', 'timed out', 'timed out']"]}], "note": "fresh student account for every round; HTTP outcomes and active sessions saved separately", "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:54:55.267982+00:00", "table_counts": {"users": 8162, "course_classes": 599, "registrations": 4103, "auth_sessions": 6687}, "violation_counts": {}, "violations": {}}, "status": "FAIL", "rounds_requested": 20}
- b9: INCONCLUSIVE — b9; requested rounds=20
  - {"name": "b9", "status": "INCONCLUSIVE", "error": "ReadTimeout: timed out", "rounds_requested": 20}
- b11: PASS — B11 natural token expiry; requested rounds=20
  - {"name": "B11 natural token expiry", "rounds": 1, "expires_at": 1793307316, "before": {"http": 200, "code": null, "elapsed_ms": 1.76}, "after": [{"http": 401, "code": "UNAUTHORIZED", "elapsed_ms": 0.97, "body": "{\"status\":\"fail\",\"data\":{\"code\":\"UNAUTHORIZED\",\"message\":\"Chưa đăng nhập hoặc phiên không hợp lệ\"}}"}, {"http": 401, "code": "UNAUTHORIZED", "elapsed_ms": 0.72, "body": "{\"status\":\"fail\",\"data\":{\"code\":\"UNAUTHORIZED\",\"message\":\"Chưa đăng nhập hoặc phiên không hợp lệ\"}}"}, {"http": 401, "code": "UNAUTHORIZED", "elapsed_ms": 0.57, "body": "{\"status\":\"fail\",\"data\":{\"code\":\"UNAUTHORIZED\",\"message\":\"Chưa đăng nhập hoặc phiên không hợp lệ\"}}"}], "violations": 0, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:55:18.137132+00:00", "table_counts": {"users": 8164, "course_classes": 599, "registrations": 4103, "auth_sessions": 6688}, "violation_counts": {}, "violations": {}}, "status": "PASS", "rounds_requested": 20}

## Chống chịu
- c1: {"failed_logins_per_s": 8.1, "reader_baseline_p95_s": 0.009312967999903776, "reader_under_flood_p95_s": 0.7429116830007843, "reader_requests": 35, "login_statuses": {"401": 121}, "reader_errors": {}, "status": "FAIL", "baseline": {"p50_s": 0.004984289000276476, "p95_s": 0.008894949000023189}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.08, "read_p95_s": 0.005707508999876154, "threshold_s": 0.026684847000069567, "api_footprint": {"rss_mb": 50.7, "fds": 32, "threads": 5}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:55:37.388533+00:00", "table_counts": {"users": 8164, "course_classes": 599, "registrations": 4103, "auth_sessions": 6688}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c2: {"requests_per_s": 1221.4, "/health 200": 6107, "/api/classes 401": 6107, "/api/missing 404": 6107, "status": "PASS", "baseline": {"p50_s": 0.004708278999714821, "p95_s": 0.008525189000465616}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.07, "read_p95_s": 0.005782699000519642, "threshold_s": 0.02557556700139685, "api_footprint": {"rss_mb": 47.7, "fds": 11, "threads": 6}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:55:55.985611+00:00", "table_counts": {"users": 8164, "course_classes": 599, "registrations": 4103, "auth_sessions": 6688}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c3: {"requested": 1000, "opened": 1000, "open_after_hold": 1000, "hold_s": 60, "fresh_request_status": 200, "fresh_request_s": 0.019, "api_before": {"rss_mb": 47.1, "fds": 9, "threads": 5}, "api_while_held": {"rss_mb": 52.4, "fds": 1009, "threads": 5}, "status": "FINDING", "baseline": {"p50_s": 0.004824498999369098, "p95_s": 0.009293807999711134}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.08, "read_p95_s": 0.005151969000507961, "threshold_s": 0.027881423999133403, "api_footprint": {"rss_mb": 58.4, "fds": 9, "threads": 5}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:57:00.672184+00:00", "table_counts": {"users": 8164, "course_classes": 599, "registrations": 4103, "auth_sessions": 6688}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c4: {"requested": 100, "opened": 100, "open_after_hold": 100, "hold_s": 30, "fresh_request_status": 200, "fresh_request_s": 0.019, "api_before": {"rss_mb": 47.8, "fds": 9, "threads": 5}, "api_while_held": {"rss_mb": 48.0, "fds": 109, "threads": 5}, "status": "FINDING", "baseline": {"p50_s": 0.004896458999610331, "p95_s": 0.010115639000105148}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.07, "read_p95_s": 0.004814420000002428, "threshold_s": 0.030346917000315443, "api_footprint": {"rss_mb": 48.5, "fds": 9, "threads": 5}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:57:34.224339+00:00", "table_counts": {"users": 8164, "course_classes": 599, "registrations": 4103, "auth_sessions": 6688}, "violation_counts": {}, "violations": {}}, "api_running": true}
- c5: {"results": [{"body_mb": 10, "status": 401, "seconds": 0.5, "rss_before_mb": 48.6, "rss_peak_mb": 109.7}, {"body_mb": 100, "status": 401, "seconds": 2.1, "rss_before_mb": 109.7, "rss_peak_mb": 707.8}], "status": "FINDING", "baseline": {"p50_s": 0.00510965900048177, "p95_s": 0.008964358999946853}, "recovery": {"status": "RECOVERED", "recovered_after_s": 2.08, "read_p95_s": 0.005814698999529355, "threshold_s": 0.02689307699984056, "api_footprint": {"rss_mb": 640.2, "fds": 9, "threads": 6}}, "integrity": {"checks": 8, "passed": true, "checked_at": "2026-10-29T20:57:40.392759+00:00", "table_counts": {"users": 8164, "course_classes": 599, "registrations": 4103, "auth_sessions": 6688}, "violation_counts": {}, "violations": {}}, "api_running": true}

## Toàn vẹn dữ liệu
Đã lưu 423 snapshot trước cleanup; không reseed giữa bài.
- Mọi snapshot đã lưu đều đạt; cần xem trạng thái nhóm để biết case nào chưa thực thi.

## Logs
- API: 7193 dòng 5xx; nguyên nhân: {'context canceled': 92220, 'timeout: context already done: context canceled': 117, 'write failed: write tcp 127.0.0.1:39026->127.0.0.1:5432: i/o timeout': 1, 'write failed: write tcp 127.0.0.1:60070->127.0.0.1:5432: i/o timeout': 1, 'write failed: write tcp 127.0.0.1:41790->127.0.0.1:5432: i/o timeout': 1}.
- api.log được giữ nguyên. Client ngắt kết nối khi hết timeout có thể gây context canceled; cần đối chiếu thời điểm trước khi quy 5xx cho server bão hòa.
- postgresql-16-main.log: 0 dòng deadlock sau khi ghi nhận môi trường.
